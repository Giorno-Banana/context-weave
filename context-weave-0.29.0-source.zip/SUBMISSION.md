# Context Weave / SourceTrail0.29.0

Textual, Answer-only generation. Add/Search generative calls:0. Embedding remains text-embedding-v4,1024 dimensions,batch10. API/profile mode:focus_stem_rules; context budget24,000 characters. Add/Search concurrency16/16.

The service preserves original sources and returns exact spans. This release changes source admission, relevance order and bounded user-instruction reservation. It retains authentication,user scope,atomic writes,request-id idempotency,immediate retrieval and persistent storage. README.md describes reproduction and the limits of public diagnostics. No official score is claimed before a completed run.

Original author:王子铭(Giorno-Banana),MIT. No upstream source code or prompt was copied for this release. See PROVENANCE.md for method inspiration and excluded LLM components.
