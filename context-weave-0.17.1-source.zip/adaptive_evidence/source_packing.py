"""Restore original source continuity without generating or rewriting evidence."""
from collections import Counter, OrderedDict
from contextlib import closing

from .core import digest


def pack_sources(store, user_id, hits, *, top_k, context_chars):
    if not hits:
        return []
    index = store.index(user_id)
    rows = {r['id']: r for r in index.rows} if index else {}
    if any(h['id'] not in rows or h['content'] != store.render(rows[h['id']]) for h in hits):
        raise ValueError('Packing requires exact original chunks in the requested scope')
    counts = Counter(r['source_id'] for r in rows.values())
    if all(counts[rows[h['id']]['source_id']] == 1 for h in hits):
        return hits
    groups = OrderedDict()
    for hit in hits:
        row = rows[hit['id']]
        groups.setdefault(row['source_id'], []).append(row)
    packets = OrderedDict()
    with closing(store.connect()) as db:
        for sid, selected in groups.items():
            # Select by BOTH the authenticated scope and source identity.
            source = db.execute('SELECT role,timestamp,length(content) AS size, '
                'substr(content,1,?) AS content FROM sources WHERE user_id=? AND id=?',
                (context_chars+1, user_id, sid)).fetchone()
            if source is None:
                raise ValueError('Source disappeared during packing')
            intervals = []
            for row in sorted(selected, key=lambda r: r['start']):
                start, end = row['start'], row['end']
                if intervals and start <= intervals[-1][1]:
                    intervals[-1][1] = max(intervals[-1][1], end)
                else:
                    intervals.append([start, end])

            def render(start, end):
                if end <= len(source['content']):
                    text = source['content'][start:end]
                else:
                    text = db.execute('SELECT substr(content,?,?) FROM sources WHERE user_id=? AND id=?',
                        (start+1, end-start, user_id, sid)).fetchone()[0]
                return store.render({'role': source['role'], 'timestamp': source['timestamp'], 'content': text})

            packets[sid] = {
                'spans': [(start, end, render(start, end)) for start, end in intervals],
            }

    # Preserve the exact union of selected evidence. A complete parent can
    # dilute a focused list or fact query, so do not introduce unselected text.
    result = []
    used = 0
    for sid, packet in packets.items():
        for start, end, text in packet['spans']:
            if used+len(text) > context_chars:
                continue
            result.append({'id': digest(['original-source-span', sid, start, end]),
                           'content': text, 'score': 1/(len(result)+1)})
            used += len(text)
            if len(result) >= top_k:
                return result
    return result
