import unittest
import test_contract as fixtures
from adaptive_evidence.source_packing import pack_sources


class SourcePackingTests(unittest.TestCase):
    setUp = fixtures.ContractTests.setUp
    tearDown = fixtures.ContractTests.tearDown
    add = fixtures.ContractTests.add

    def hits(self, rows):
        return [{'id': r['id'], 'content': self.store.render(r), 'score': 1/(i+1)}
                for i, r in enumerate(rows)]

    def test_disconnected_intervals_keep_gap_and_restore_source_order(self):
        content = ''.join(f'Step {i:03}: original action {i}.\n' for i in range(150))
        self.add(content=content, timestamp=1735689600000)
        rows = self.store.index('u').rows
        result = pack_sources(self.store, 'u', self.hits([rows[-1], rows[0]]), top_k=2, context_chars=5000)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['content'], self.store.render(rows[0]))
        self.assertEqual(result[1]['content'], self.store.render(rows[-1]))

    def test_reserves_other_selected_sources_before_parent_expansion(self):
        self.add(content='A long source. '*400)
        self.add(request='b', content='Separate critical constraint.')
        rows = self.store.index('u').rows
        a = next(r for r in rows if r['request_id']=='r')
        b = next(r for r in rows if r['request_id']=='b')
        result = pack_sources(self.store, 'u', self.hits([a,b]), top_k=2, context_chars=1600)
        self.assertEqual(len(result), 2)
        self.assertIn('Separate critical constraint.', result[1]['content'])
        self.assertLessEqual(sum(len(h['content']) for h in result), 1600)

    def test_merges_overlap_without_duplicate_source_words(self):
        self.add(content=''.join(f'Word{i:04} ' for i in range(1000)))
        rows = self.store.index('u').rows
        result = pack_sources(self.store, 'u', self.hits([rows[1], rows[0]]), top_k=2, context_chars=2200)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['content'].count('Word0100'), 1)
        self.assertLessEqual(len(result[0]['content']), 2200)

    def test_foreign_source_and_modified_text_rejected(self):
        self.add(content='A source. '*200)
        self.add(user='other', content='Other private source. '*200)
        with self.assertRaises(ValueError):
            pack_sources(self.store, 'u', self.hits(self.store.index('other').rows[:1]), top_k=1, context_chars=4000)
        hits = self.hits(self.store.index('u').rows[:1])
        hits[0]['content'] += ' fabricated'
        with self.assertRaises(ValueError):
            pack_sources(self.store, 'u', hits, top_k=1, context_chars=4000)

    def test_short_messages_unchanged(self):
        self.add(content='A short fact.')
        hits = self.hits(self.store.index('u').rows)
        self.assertEqual(pack_sources(self.store, 'u', hits, top_k=1, context_chars=24000), hits)


if __name__ == '__main__':
    unittest.main()
