# Active0.17.1 profile

Read README.md and EXPERIMENT.json. Local Qwen3.5-4B runtime0.4.2 and text-embedding-v4. API18098; model18095. Fresh database required. Merge selected original source spans; optional Add cue failures use unchanged source. Official score pending. No Full or new OpenRouter calls authorized.
