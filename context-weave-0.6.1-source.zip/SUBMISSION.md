# 0.6.1 submission preparation

Experimental Search planner based on the unchanged 0.4.1 Add and supervised model runtime. No official 0.6.1 run has started. The acceptance target is Textual Smoke strictly above 70, with all evaluation items complete and the evaluated source verified unchanged.

| Field | Value |
| --- | --- |
| Repository | Giorno-Banana/context-weave |
| Contact / team | 秦天朗 / recursive roll |
| Code copyright / license | 王子铭 / MIT |
| Add LLM | Local Qwen3.5-4B, BF16, thinking disabled |
| Search LLM | Local Qwen3.5-4B, internal query expansion and source-ID selection |
| Embedding | Bailian text-embedding-v4, 1024 dimensions |
| Worker runtime | Unchanged 0.4.1 |
| Runtime revision | sha256-82566a6da25518d98b91c78ce9a7c5a3d09aee59dd25db5b123f65811ed8acfe |
| Local candidate API | 127.0.0.1:18088 |
| Local model endpoint | 127.0.0.1:18091 |
| Official 0.6.1 score | Not run |
| Full | Not started |

The current public root remains stable 0.4.1, score 58.82. The historical best is 59.47 from 0.4.0. Candidate public QA cannot be reported as an official score. Freeze and publish the exact source and profile before binding a version and starting official Smoke. This document contains no evaluator key or API authentication token.
