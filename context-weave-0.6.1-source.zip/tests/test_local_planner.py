import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import httpx
import test_contract as fixtures
from adaptive_evidence.local_planner import EvidenceSearch, LocalEvidencePlanner, LocalPlanningError


class SelectionTests(unittest.TestCase):
    setUp=fixtures.ContractTests.setUp
    tearDown=fixtures.ContractTests.tearDown
    add=fixtures.ContractTests.add

    def test_cannot_return_generated_text_or_other_user(self):
        self.add(content='Luna likes climbing.')
        self.add(user='other',request='private',content='Private hidden fact.')
        class Planner:
            def expand(self,*args):return ['totally unrelated invented query']
            def select(self,*args):return [1]
        result=EvidenceSearch(self.store,Planner()).search(user_id='u',query='What does Luna like?',top_k=1)
        self.assertEqual(len(result),1)
        self.assertIn('Luna likes climbing.',result[0]['content'])
        self.assertNotIn('invented',str(result))
        self.assertNotIn('Private',str(result))

    def test_invalid_identifier_falls_back_to_original_sources(self):
        self.add(content='Luna likes climbing.')
        args={'user_id':'u','query':'Luna','top_k':1}
        baseline=self.store.search(**args)
        class Planner:
            def expand(self,*args):return []
            def select(self,*args):return [False,999]
        self.assertEqual(EvidenceSearch(self.store,Planner()).search(**args),baseline)

    def test_unavailable_model_retains_baseline(self):
        self.add(content='Luna likes climbing.')
        args={'user_id':'u','query':'Luna','top_k':1}
        class Planner:
            def expand(self,*args):raise LocalPlanningError('unavailable')
            def select(self,*args):raise LocalPlanningError('unavailable')
        self.assertEqual(EvidenceSearch(self.store,Planner()).search(**args),self.store.search(**args))

    def test_topk_rejected_before_model(self):
        for n in [True,0,101]:
            with self.assertRaises(ValueError):EvidenceSearch(self.store,None).search(user_id='u',query='Luna',top_k=n)

    def test_empty_scope_does_not_call_model(self):
        self.assertEqual(EvidenceSearch(self.store,None).search(user_id='empty',query='Luna'),[])


class EndpointTests(unittest.TestCase):
    def test_external_endpoint_rejected_before_loading_tokenizer(self):
        with self.assertRaises(ValueError):LocalEvidencePlanner('missing','https://example.com/completions')
