# Candidate status

0.6.1 adds bounded local evidence planning to the stable 0.4.1 source. Add indexing, model weights and the supervised worker runtime are unchanged. Candidate regression and live synthetic HTTP checks passed; paired public QA completed at 29/50 versus 30/50, an inconclusive difference. No official 0.6.1 Smoke or Full has started. The current target is an official Smoke score strictly above 70.

Historical official Smoke: 0.4.0 scored 59.47 with recovery interventions; 0.4.1 scored 58.82 and completed stably; 0.5.0 failed without a score; 0.5.1 scored 51.56 and was not promoted. The public root is stable 0.4.1. Scores belong only to their evaluated frozen versions.

See EXPERIMENT.json for candidate validation, README.md for the method and deployment profile, and PROVENANCE.md for inspected source repositories. Public development results and same-model judgments do not establish future official performance.

## Public comparison decision

The 50-question development comparison yielded 29 baseline and 30 candidate correct answers under the automatic local judge, with 9 wins and 8 losses; the paired 95% bootstrap interval is -14 to +18 percentage points. The predeclared statistical advancement criterion was NOT met. Source identity remained unchanged. Selection validation failures were zero; four query-expansion calls fell back to baseline expansion behavior. These are development diagnostics, not official scores. A separate prospective plan, recorded before candidate answers, permits one exploratory official Smoke after mechanical validation and excludes major public regressions. It does not override or relabel the failed statistical gate. See local_runtime/SEARCH_VALIDATION.json. No Full will be started by this experiment.
