# 0.9.0 candidate status

Local Qwen3.5-9B-Q5_K_M with llama.cpp b11429 CUDA. No official score yet. Smoke only; Full is not authorized. See README.md and EXPERIMENT.json for active configuration, public results, limitations and reported organizer permission. Older retained experiment files are historical.
