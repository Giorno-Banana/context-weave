# Active 0.9.0 runtime

The active model is Qwen3.5-9B-Q5_K_M with llama.cpp b11429 CUDA. Use start_llamacpp.ps1 and the exact external assets/configuration in LLAMACPP_MANIFEST.json. Set LogDirectory to a private directory outside the source tree. The launcher binds only to loopback. No GPU driver changes are performed.

The old Torch supervised runtime and MODEL_MANIFEST.json are retained as historical source and test dependencies, not used by this release. The public diagnostic answer/judge used a separate 4B runtime042; official Search never invokes that answer/judge.
