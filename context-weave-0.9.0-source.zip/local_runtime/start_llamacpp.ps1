param(
    [ValidateSet('cuda','vulkan')][string]$Backend='cuda',
    [string]$AssetDirectory='D:\context-weave-local-models\qwen35-9b-experiment',
    [int]$Port=18096,
    [string]$LogDirectory=''
)
$ErrorActionPreference='Stop'
$runtimeDirectory=Join-Path $AssetDirectory ('llamacpp-'+$Backend)
$matches=@(Get-ChildItem -LiteralPath $runtimeDirectory -Filter 'llama-server.exe' -Recurse -File)
if ($matches.Count -ne 1) { throw 'Expected exactly one pinned llama-server executable' }
$libraryDirectories=@(Get-ChildItem -LiteralPath $runtimeDirectory -Filter '*.dll' -Recurse -File | Select-Object -ExpandProperty DirectoryName -Unique)
$env:PATH=($libraryDirectories -join ';')+';'+$env:PATH
$modelFile=Join-Path $AssetDirectory 'Qwen3.5-9B-Q5_K_M.gguf'
if (!(Test-Path -LiteralPath $modelFile)) { throw 'Missing model asset' }
if (!$LogDirectory) { $LogDirectory=Join-Path $PSScriptRoot 'private-logs' }
New-Item -ItemType Directory -Force -Path $LogDirectory | Out-Null
# Environment passes JSON without Windows command-line quote loss.
$env:LLAMA_ARG_CHAT_TEMPLATE_KWARGS='{"enable_thinking":false}'
$serverArguments=@('--model',('"'+$modelFile+'"'),'--alias','Qwen3.5-9B-Q5_K_M',
    '--host','127.0.0.1','--port',[string]$Port,'--ctx-size','8192','--parallel','1',
    '--gpu-layers','all','--fit','off','--batch-size','512','--ubatch-size','256',
    '--flash-attn','on','--temp','0','--seed','42','--predict','1024',
    '--reasoning','off','--reasoning-budget','0','--jinja',
    '--no-cache-prompt','--cache-ram','0','--no-cache-idle-slots','--ctx-checkpoints','0',
    '--no-context-shift','--timeout','180','--metrics','--log-disable')
$process=Start-Process -FilePath $matches[0].FullName -ArgumentList $serverArguments -WorkingDirectory $matches[0].DirectoryName -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $LogDirectory 'llama.stdout.log') -RedirectStandardError (Join-Path $LogDirectory 'llama.stderr.log')
@{ pid=$process.Id;backend=$Backend;port=$Port;created=(Get-Date -Format o);model='Qwen3.5-9B-Q5_K_M';executable=$matches[0].FullName } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $LogDirectory 'process.json') -Encoding utf8
$process.WaitForExit()
exit $process.ExitCode
