"""Adjacent original-source bundles with bounded size and stable provenance.

Packing changes the unit of a result, never the text or retrieval scope.
Ordering exists only inside the same ordered Add request. Arbitrary request
IDs are not interpreted as timestamps or used to infer event chronology.
"""
from collections import defaultdict
from datetime import datetime, timezone
from .core import digest


def select_bundles(store, index, ranked, top_k):
    groups = defaultdict(list)
    for i, row in enumerate(index.rows):
        groups[(row['session_id'], row['request_id'])].append(i)
    locations = {}
    for group in groups.values():
        group.sort(key=lambda i: (index.rows[i]['position'], index.rows[i]['start']))
        for p, i in enumerate(group):
            locations[i] = (group, p)
    seen = set()
    covered = defaultdict(list)
    output = []
    used = 0
    budget = store.config.context_chars
    # All groups are computed from this user's immutable index snapshot.
    for seed in ranked[:store.config.candidate_k]:
        if seed in seen or len(output) >= top_k:
            continue
        row = index.rows[seed]
        if any(a <= row['start'] and b >= row['end'] for a, b in covered[row['source_id']]):
            continue
        group, p = locations[seed]
        bundle = []
        size = 0
        max_item = min(4000, budget - used)
        # The direct hit is mandatory; neighbors may only spend remaining room.
        for offset in (0, -1, 1, -2, 2):
            if not 0 <= p + offset < len(group):
                continue
            i = group[p + offset]
            part = index.rows[i]
            if i in seen or any(a <= part['start'] and b >= part['end'] for a, b in covered[part['source_id']]):
                continue
            length = len(store.render(part)) + (2 if bundle else 0)
            if size + length > max_item:
                if offset == 0:
                    break
                continue
            bundle.append(i)
            size += length
        if not bundle:
            continue
        bundle.sort(key=lambda i: (index.rows[i]['position'], index.rows[i]['start']))
        output.append((seed, bundle))
        used += size
        for i in bundle:
            seen.add(i)
            part = index.rows[i]
            covered[part['source_id']].append((part['start'], part['end']))
    return output


def render_bundles(store, index, ranked, top_k):
    result = []
    for seed, members in select_bundles(store, index, ranked, top_k):
        item = {'id': 'bundle-' + digest([index.rows[i]['id'] for i in members]),
                'content': '\n\n'.join(store.render(index.rows[i]) for i in members),
                'score': 1.0 / (len(result) + 1)}
        timestamp = index.rows[seed]['timestamp']
        if timestamp is not None:
            item['created_at'] = datetime.fromtimestamp(timestamp / 1000, timezone.utc).isoformat()
        result.append(item)
    return result
