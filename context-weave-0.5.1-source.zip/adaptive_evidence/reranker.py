"""Bounded client for an explicitly configured local cross-encoder."""
import math
import logging
from urllib.parse import urlsplit

import httpx


class RerankerError(RuntimeError):
    pass


class LocalReranker:
    def __init__(self, endpoint="http://127.0.0.1:18092", *, transport=None):
        parsed = urlsplit(endpoint)
        if (parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "::1", "localhost"}
                or parsed.username or parsed.password or parsed.query or parsed.fragment
                or parsed.path not in {"", "/"}):
            raise ValueError("Reranker must use a loopback HTTP endpoint")
        self.client = httpx.Client(base_url=endpoint.rstrip("/")+"/", timeout=120,
                                   trust_env=False, transport=transport, follow_redirects=False)
        response = self.client.get("health")
        response.raise_for_status()
        self.identity = response.json()["identity"]

    def score(self, query, documents):
        try:
            response = self.client.post("rerank", json={"query": query, "documents": documents})
            response.raise_for_status()
            body = response.json()
            values = body["scores"]
            if (body.get("identity") != self.identity or not isinstance(values, list)
                    or len(values) != len(documents)
                    or any(type(v) not in (float, int) or not math.isfinite(v) for v in values)):
                raise ValueError("Invalid reranker response")
            return values
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as error:
            response = getattr(error, "response", None)
            logging.getLogger(__name__).warning("reranker_failure type=%s status=%s", type(error).__name__,
                                                getattr(response, "status_code", None))
            raise RerankerError("Configured local reranker unavailable or invalid") from None

    def close(self):
        self.client.close()


def fuse_reranking(index, ranked, scores):
    """RRF gives the reranker priority while retaining hybrid retrieval signal."""
    pool = ranked[:len(scores)]
    by_cross = sorted(range(len(pool)), key=lambda n: (-scores[n], n))
    cross_rank = {n: rank for rank, n in enumerate(by_cross, 1)}
    fused = [.7/(20+cross_rank[n]) + .3/(20+n+1) for n in range(len(pool))]
    return [pool[n] for n in sorted(range(len(pool)), key=lambda n: (-fused[n], n))] + ranked[len(pool):]
