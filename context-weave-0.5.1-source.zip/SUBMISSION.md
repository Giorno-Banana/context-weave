# Deployment

Version 0.5.1. Fixed bundle at https://github.com/Giorno-Banana/context-weave . Official Add/Search use the existing root HTTPS endpoints; private authentication is inherited. Add/Search concurrency 16/16, top_k 100, 96,000-character source budget. Local Qwen3.5-4B Add and CPU MiniLM reranking are disclosed. See README for runtime, validation, and permissions limitations.
