import unittest
import test_contract as fixtures
from adaptive_evidence.core import Config, MemoryStore
from adaptive_evidence.bundles import select_bundles, render_bundles


class BundleTests(unittest.TestCase):
    setUp=fixtures.ContractTests.setUp
    tearDown=fixtures.ContractTests.tearDown

    def populate(self):
        for user in ('u','private-other'):
            for request in ('episode-1','episode-2'):
                self.store.add(user_id=user, request_id=request, session_id='same-session', messages=[
                    {'role':'user' if i % 2 == 0 else 'assistant',
                     'content':f'{user} {request} message {i}: exact source text, including punctuation. ',
                     'timestamp':1700000000000+i*1000} for i in range(7)])

    def test_expands_short_evidence_without_crossing_requests_or_users(self):
        self.store=MemoryStore(self.path,self.encoder,Config(context_chars=64000,bundled_context=True))
        self.populate();index=self.store.index('u');ranked=list(range(len(index.rows)))
        bundles=select_bundles(self.store,index,ranked,100)
        self.assertLess(len(bundles),len(ranked))
        members=[i for _,group in bundles for i in group]
        self.assertEqual(set(members),set(ranked))
        self.assertEqual(len(members),len(set(members)))
        for _,group in bundles:
            self.assertEqual(1,len({index.rows[i]['request_id'] for i in group}))
            self.assertEqual(group,sorted(group,key=lambda i:index.rows[i]['position']))
        hits=self.store.search(user_id='u',query='exact source',mode='evidence')
        self.assertNotIn('private-other',str(hits))
        self.assertEqual(hits,self.store.search(user_id='u',query='exact source',mode='evidence'))

    def test_budget_top_k_direct_hit_and_exact_original_text(self):
        self.store=MemoryStore(self.path,self.encoder,Config(context_chars=410,bundled_context=True))
        self.populate();index=self.store.index('u');ranked=list(reversed(range(len(index.rows))))
        bundles=select_bundles(self.store,index,ranked,2)
        hits=render_bundles(self.store,index,ranked,2)
        self.assertLessEqual(len(hits),2)
        self.assertLessEqual(sum(len(h['content']) for h in hits),410)
        self.assertIn(ranked[0],bundles[0][1])
        for hit,(_,group) in zip(hits,bundles):
            self.assertEqual(hit['content'],'\n\n'.join(self.store.render(index.rows[i]) for i in group))
        self.assertEqual(1,len(render_bundles(self.store,index,ranked,1)))

    def test_successful_add_invalidates_bundle_index(self):
        self.store=MemoryStore(self.path,self.encoder,Config(bundled_context=True))
        self.populate()
        self.store.search(user_id='u',query='new amber reservation',mode='evidence')
        self.store.add(user_id='u',request_id='new',session_id='new',messages=[{'role':'user','content':'New amber reservation.'}])
        self.assertIn('New amber reservation.',str(self.store.search(user_id='u',query='new amber reservation',mode='evidence')))
