"""Losslessly append bounded episode windows around exact-0.32 nuclei.

The baseline stream is retained byte-for-byte as a prefix.  This module only
uses otherwise-unused character budget and verified ordering inside one Add.
"""
from collections import defaultdict
from datetime import datetime, timezone

from .core import digest
from .source_catalog import catalog, decode


def extend_episode_windows(index, ranked, baseline, budget, top_k, render):
    del ranked  # Baseline order already defines nucleus priority.
    groups = decode(index, baseline, render)
    if groups is None or top_k < 8 or len(baseline) != top_k:
        return baseline

    originals = {row['source_id']: row for _, row in catalog(index, render)}
    request_sources = defaultdict(dict)
    for row in index.rows:
        key = (row['session_id'], row['request_id'])
        request_sources[key].setdefault(row['position'], row['source_id'])

    ordered_sources = {
        key: [source_id for _, source_id in sorted(by_position.items())]
        for key, by_position in request_sources.items()
    }
    source_locations = {}
    for key, source_ids in ordered_sources.items():
        for position, source_id in enumerate(source_ids):
            source_locations[source_id] = (key, position)

    # MemMachine's episode cluster is previous 1 / next 2.  When the entire
    # cluster cannot fit, equal-distance future context wins before the past.
    candidate_sources = []
    seen_candidates = set(groups)
    for nucleus_source in groups:
        location = source_locations.get(nucleus_source)
        if location is None:
            continue
        key, position = location
        source_ids = ordered_sources[key]
        for offset in (1, -1, 2):
            neighbor = position + offset
            if not 0 <= neighbor < len(source_ids):
                continue
            source_id = source_ids[neighbor]
            if source_id in seen_candidates:
                continue
            seen_candidates.add(source_id)
            candidate_sources.append(source_id)

    fragments = list(baseline)
    parts = []
    for source_id, group in groups.items():
        for position, (start, end) in zip(group['indices'], group['intervals']):
            while len(parts) <= position:
                parts.append(None)
            parts[position] = {
                'id': baseline[position]['id'], 'source_id': source_id,
                'start': start, 'end': end,
            }
    if any(part is None for part in parts):
        return baseline

    used = len('\n\n'.join(hit['content'] for hit in fragments))
    for source_id in candidate_sources:
        row = originals.get(source_id)
        if row is None or not row['content']:
            continue
        content = render(row)
        if used + 2 + len(content) > budget:
            continue
        hit = {
            'id': digest([source_id, 0, len(row['content'])]),
            'content': content,
            'score': 1.0 / (len(fragments) + 1),
        }
        if row['timestamp'] is not None:
            hit['created_at'] = datetime.fromtimestamp(
                row['timestamp'] / 1000, timezone.utc).isoformat()
        fragments.append(hit)
        parts.append({
            'id': hit['id'], 'source_id': source_id,
            'start': 0, 'end': len(row['content']),
        })
        used += 2 + len(content)
        if len(fragments) == 2 * top_k:
            break

    if len(fragments) == len(baseline):
        return baseline

    result = []
    for start in range(0, len(fragments), 2):
        pair = fragments[start:start + 2]
        provenance = parts[start:start + 2]
        result.append({
            'id': digest(['memmachine_recall_bundle:v1',
                          [piece['id'] for piece in provenance]]),
            'content': '\n\n'.join(piece['content'] for piece in pair),
            'score': 1.0 / (len(result) + 1),
            'provenance': provenance,
        })

    assert len(result) <= top_k
    rendered = '\n\n'.join(hit['content'] for hit in result)
    baseline_rendered = '\n\n'.join(hit['content'] for hit in baseline)
    assert len(rendered) <= budget
    assert rendered.startswith(baseline_rendered + '\n\n')
    return result
