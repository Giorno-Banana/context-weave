"""Literal source catalog and span verification, independent of scoring."""
from collections import OrderedDict
from .core import digest
from .evidence_windows import merged_rows

def catalog(index, render):
    with index.view_lock:
        cached = getattr(index, '_source_exchange_catalog', None)
        if cached is not None:
            return cached
        result = []
        source_ends = {}
        for chunk in index.rows:
            source_ends[chunk['source_id']] = max(source_ends.get(chunk['source_id'], 0), chunk['end'])
        for _, row in merged_rows(index, list(range(len(index.rows)))):
            if row['start'] != 0 or row['end'] != len(row['content']) or row['end'] != source_ends[row['source_id']]:
                continue
            header = render({**row, 'content': ''})
            result.append((header, row))
        index._source_exchange_catalog = result
        return result

def decode(index, hits, render):
    originals = catalog(index, render)
    groups = OrderedDict()
    for position, hit in enumerate(hits):
        found = None
        for header, original in originals:
            if not hit['content'].startswith(header):
                continue
            body = hit['content'][len(header):]
            start = original['content'].find(body)
            while start >= 0:
                end = start + len(body)
                if digest([original['source_id'], start, end]) == hit['id']:
                    found = (original, start, end)
                    break
                start = original['content'].find(body, start + 1)
            if found is not None:
                break
        if found is None:
            return None
        original, start, end = found
        group = groups.setdefault(original['source_id'], {'original': original, 'indices': [], 'intervals': [], 'chars': 0})
        group['indices'].append(position)
        group['intervals'].append((start, end))
        group['chars'] += len(hit['content'])
    for group in groups.values():
        covered, end = (0, 0)
        contiguous = True
        for start, stop in sorted(group['intervals']):
            contiguous = contiguous and start <= end
            covered += max(0, stop - max(start, end))
            end = max(end, stop)
        group['covered'] = covered
        group['complete'] = contiguous and end == len(group['original']['content'])
    return groups
