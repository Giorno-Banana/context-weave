import tempfile
import unittest
from pathlib import Path

from adaptive_evidence.core import Config, MemoryStore, digest
from adaptive_evidence.memmachine_recall import extend_episode_windows
from adaptive_evidence.source_catalog import decode
from test_contract import FakeEncoder


class MemMachineRecallTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = MemoryStore(
            Path(self.temp.name) / 'memory.db', FakeEncoder(),
            Config(context_chars=24000),
        )
        self.messages = [
            {
                'role': 'user' if i % 2 == 0 else 'assistant',
                'content': 'Project amber episode %02d: one distinct original fact.' % i,
                'timestamp': 1700000000000 + i * 1000,
            }
            for i in range(32)
        ]
        self.store.add(user_id='u', request_id='r', session_id='s',
                       messages=self.messages)

    def tearDown(self):
        self.temp.cleanup()

    def search(self, mode='memmachine_recall', k=8):
        return self.store.search(user_id='u', query='Project amber original fact',
                                 top_k=k, mode=mode)

    def test_baseline_is_unchanged_prefix_and_all_additions_are_exact_episodes(self):
        baseline = self.search('query_document_evidence')
        candidate = self.search()
        old = '\n\n'.join(hit['content'] for hit in baseline)
        new = '\n\n'.join(hit['content'] for hit in candidate)
        self.assertTrue(new.startswith(old + '\n\n'))
        self.assertGreater(len(new), len(old))
        self.assertLessEqual(len(candidate), 8)
        index = self.store.index('u')
        rows = {row['source_id']: row for row in index.rows}
        flat = [part for hit in candidate for part in hit['provenance']]
        for part in flat:
            row = rows[part['source_id']]
            self.assertEqual(part['id'], digest([
                part['source_id'], part['start'], part['end']]))
            self.assertGreater(part['end'], part['start'])
            self.assertLessEqual(part['end'], len(row['content']))
        for part in flat[len(baseline):]:
            row = rows[part['source_id']]
            self.assertEqual((part['start'], part['end']),
                             (0, len(row['content'])))

    def test_episode_neighbors_use_next_then_previous_then_second_next(self):
        baseline = self.search('query_document_evidence')
        candidate = self.search()
        index = self.store.index('u')
        baseline_sources = list(decode(index, baseline, self.store.render))
        positions = {digest(['u', 'r', i]): i for i in range(len(self.messages))}
        seen = set(baseline_sources)
        expected = []
        for source_id in baseline_sources:
            position = positions[source_id]
            for offset in (1, -1, 2):
                neighbor = position + offset
                if not 0 <= neighbor < len(self.messages):
                    continue
                candidate_id = digest(['u', 'r', neighbor])
                if candidate_id in seen:
                    continue
                seen.add(candidate_id)
                expected.append(candidate_id)
        flat = [part for hit in candidate for part in hit['provenance']]
        additions = [part['source_id'] for part in flat[len(baseline):]]
        self.assertEqual(additions, expected[:len(additions)])
        self.assertTrue(any(
            positions[source] == positions[nucleus] + 2
            for source in additions for nucleus in baseline_sources
        ))

    def test_small_top_k_nonbinding_count_and_no_budget_are_unchanged(self):
        self.assertEqual(self.search('query_document_evidence', 1), self.search(k=1))
        self.assertEqual(self.search('query_document_evidence', 100), self.search(k=100))
        baseline = self.search('query_document_evidence')
        index = self.store.index('u')
        ranked = self.store.ranked(index, 'Project amber original fact', None,
                                   'query_document_evidence')
        budget = len('\n\n'.join(hit['content'] for hit in baseline))
        self.assertEqual(
            baseline,
            extend_episode_windows(index, ranked, baseline, budget, 8,
                                   self.store.render),
        )

    def test_never_crosses_add_boundary(self):
        baseline = self.search('query_document_evidence')
        self.store.add(user_id='u', request_id='separate', session_id='s',
                       messages=[{'role': 'user', 'content': 'Separate Add.'}])
        candidate = self.search()
        flat = [part for hit in candidate for part in hit.get('provenance', [])]
        separate = digest(['u', 'separate', 0])
        self.assertNotIn(separate, [part['source_id'] for part in flat])
        self.assertTrue('\n\n'.join(hit['content'] for hit in candidate).startswith(
            '\n\n'.join(hit['content'] for hit in baseline)))


if __name__ == '__main__':
    unittest.main()
