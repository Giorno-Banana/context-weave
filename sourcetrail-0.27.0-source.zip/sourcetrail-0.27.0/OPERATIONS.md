# SourceTrail 0.27.0 — LLM only at Answer

Add/Search contain no generative LLM implementation or chat-completions client. In the official AML workflow, the external evaluator performs Answer using its configured LLM after receiving the original evidence from Search. This package implements only the memory Add/Search contract; it does not add an unofficial /answer endpoint or change the evaluator's model.

Add preserves complete original messages, splits them into at most 1000-character spans with 120-character overlap, and embeds the unmodified spans using text-embedding-v4 (1024 dimensions). Each embedding request carries up to 10 spans. There is no cue extraction, summarization, model-selected span repetition, or Add GPU queue.

Search uses original-query and caller-option embeddings, BM25, reciprocal-rank fusion, source deduplication, and neighboring original messages within the same ordered Add request. It returns source evidence within a 24,000-character budget; it never plans queries, selects evidence with a generative model, or generates an answer. Embedding calls remain in both Add and Search. Historical LLM-enable environment flags cannot enable chat calls in this release because the implementations are absent.

Authentication, atomic immediately searchable Add, request_id idempotence/conflict checking, user isolation, persistent checkpoints, and original timestamps remain. A new schema identity rejects older databases. Use a separate empty database for this candidate; preserve the original Full database.

## Run

Install requirements.txt. Copy env.example into a private credentials file and provide the embedding endpoint, keys and an explicit new database. No local Qwen service, tokenizer, or generative model key is required.

```powershell
.\start_local.ps1 -Port 18092 -PythonPath C:\service-venv\Scripts\python.exe -EnvFile @('.env')
python preflight.py --env-file .env
python preflight.py --env-file .env --live --output synthetic-probe.json
python -m unittest discover -s tests
```

Preflight is offline unless --live is specified. Live uses only synthetic memories in a temporary database and calls only the embedding provider. It does not submit a Smoke/Full or modify a deployment route.

This is a new candidate derived from frozen 0.6.1 fastbatch. It has no official score. Neither speed nor accuracy gains are claimed without a comparison. In particular, removing LLM cue weighting and evidence planning may change retrieval quality. Source attribution and licensing are in PROVENANCE.md and LICENSE.

## Release identity

SourceTrail is the submission name for this frozen 0.27.0 raw-source-memory release of Context Weave. Original code author/copyright: 王子铭 (Giorno-Banana), MIT. Only release documentation differs from the deployed package; every Python source file and runtime configuration template is byte-identical. The runtime health response may retain the underlying Context Weave identity. The submission package does not include credentials, databases or evaluation data.
