"""Raw-source memory API; generative LLM calls belong to the evaluator Answer stage."""

__version__ = "0.27.0"
