import json
from pathlib import Path
import tempfile
import threading
import unittest
import httpx
from adaptive_evidence.cloud_planner import CloudEvidencePlanner
from adaptive_evidence.cloud_budget import CloudBudget,BudgetedClient
from adaptive_evidence.local_planner import LocalPlanningError

class CloudPlannerTests(unittest.TestCase):
    def planner(self,value,model='openai/gpt-4o-mini'):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        budget=CloudBudget(Path(tmp.name)/'budget.sqlite3')
        planner=object.__new__(CloudEvidencePlanner)
        planner.tokens=lambda text:list(text.encode())
        planner.endpoint='https://openrouter.ai/api/v1/chat/completions'
        def handler(req):return httpx.Response(200,json={'model':model,'choices':[{'finish_reason':'stop','message':{'content':json.dumps(value)}}],
                                                        'usage':{'cost':.001,'prompt_tokens':10,'completion_tokens':5}})
        planner.client=BudgetedClient(httpx.Client(transport=httpx.MockTransport(handler)),budget,'search')
        self.addCleanup(planner.close)
        planner.slots=threading.BoundedSemaphore(4);planner.lock=threading.Lock()
        planner.calls=planner.failures=planner.prompt_tokens=planner.completion_tokens=0
        return planner,budget

    def test_only_whitelisted_integer_ids_returned(self):
        for ids in [[999],[True],['1'],list(range(17))]:
            p,b=self.planner({'ids':ids})
            with self.assertRaises(LocalPlanningError):p.request('ids',{'memories':[{'id':1,'content':'synthetic'}]})
            self.assertEqual(.001,b.summary()['confirmed_cost_usd'])
        p,_=self.planner({'ids':[1,1]})
        self.assertEqual([1],p.request('ids',{'memories':[{'id':1,'content':'synthetic'}]}))

    def test_wrong_model_and_malformed_queries_rejected(self):
        for value,model in [({'queries':['a']},'other'),({'queries':['x'*241]},'openai/gpt-4o-mini'),({'answer':'invented'},'openai/gpt-4o-mini')]:
            p,_=self.planner(value,model)
            with self.assertRaises(LocalPlanningError):p.request('queries',{})

    def test_exhausted_budget_is_safe_planning_failure(self):
        p,b=self.planner({'queries':[]})
        for _ in range(33):b.reserve('unknown')
        with self.assertRaises(LocalPlanningError):p.request('queries',{})
        self.assertEqual(33,b.summary()['requests'])

if __name__=='__main__':unittest.main()
