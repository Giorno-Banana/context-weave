import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from fastapi.testclient import TestClient

import preflight
from adaptive_evidence.add_indexer import AddIndexerError, LocalAddIndexer, OpenRouterAddIndexer, add_indexer_from_env
from adaptive_evidence.api import app, get_store
from adaptive_evidence.core import MemoryStore
from test_contract import FakeEncoder
from test_preflight import SETTINGS


def local_response(request):
    payload = json.loads(request.content)
    chunks = json.loads(payload['messages'][1]['content'])
    output = {key: {'first': 0, 'second': -1, 'third': -1} for key in chunks}
    return httpx.Response(200, json={'model': 'Qwen3.5-4B', 'choices': [
        {'finish_reason': 'stop', 'message': {'content': json.dumps(output)}}]})


class LocalIndexerTests(unittest.TestCase):
    def indexer(self, handler=local_response, **kwargs):
        result = LocalAddIndexer('Qwen3.5-4B', 'test-revision-1',
            transport=httpx.MockTransport(handler), sleep=lambda _: None, **kwargs)
        self.addCleanup(result.close)
        return result

    def test_local_route_has_schema_prompt_and_no_cloud_credentials(self):
        calls = []
        def handler(request):
            calls.append(request)
            self.assertEqual('127.0.0.1', request.url.host)
            self.assertNotIn('Authorization', request.headers)
            payload = json.loads(request.content)
            self.assertNotIn('provider', payload)
            self.assertNotIn('store', payload)
            self.assertEqual('Qwen3.5-4B', payload['model'])
            self.assertIn('Required JSON schema:', payload['messages'][0]['content'])
            return local_response(request)
        with patch.dict(os.environ, {'OPENROUTER_API_KEY': 'cloud-secret', 'HTTP_PROXY': 'http://bad.invalid'}):
            indexer = self.indexer(handler)
            texts = ['Maya moved to Berlin.', '日期：十一月十八日。', 'Luna prefers trains.']
            self.assertEqual([s + '\n' + s for s in texts], indexer.enrich(texts))
            self.assertEqual(2, len(calls))
            self.assertFalse(indexer.client.trust_env)

    def test_nonlocal_endpoints_and_missing_identity_fail_before_network(self):
        for endpoint in ('https://openrouter.ai/v1/chat/completions',
                         'http://127.0.0.1:18090/v1/chat/completions?key=private',
                         'http://secret@localhost/v1/chat/completions',
                         'http://localhost:0/v1/chat/completions',
                         'http://localhost:99999/v1/chat/completions',
                         'http://localhost/v1/other', 'http://localhost.evil.test/v1/chat/completions'):
            with self.subTest(endpoint=endpoint), self.assertRaises(ValueError):
                self.indexer(endpoint=endpoint)
        for model, revision in (('', 'rev'), ('Qwen3.5-4B', ''), ('bad\nname', 'rev')):
            with self.assertRaises(ValueError):
                LocalAddIndexer(model, revision)

    def test_wrong_model_invalid_ids_and_truncation_fail_closed(self):
        bodies = [
            {'model': 'gpt-4o-mini', 'choices': []},
            {'model': 'Qwen3.5-4B', 'choices': [{'finish_reason': 'length', 'message': {'content': '{}'}}]},
            {'model': 'Qwen3.5-4B', 'choices': [{'finish_reason': 'stop', 'message': {'content':
                json.dumps({'c0': {'first': 999, 'second': -1, 'third': -1}})}}]},
            {'model': 'Qwen3.5-4B', 'choices': [{'finish_reason': 'stop', 'message': {'content': '```json\n{}\n```'}}]},
        ]
        for body in bodies:
            model = self.indexer(lambda _, body=body: httpx.Response(200, json=body), max_attempts=1)
            with self.assertRaises(AddIndexerError):
                model.enrich(['Secret source'])
            self.assertEqual(1, model.requests)

    def test_failed_local_request_never_falls_back_to_cloud(self):
        urls = []
        def handler(request):
            urls.append(str(request.url))
            return httpx.Response(503, text='private-key source-text')
        model = self.indexer(handler)
        with self.assertRaises(AddIndexerError) as error:
            model.enrich(['source-text'])
        self.assertEqual([model.endpoint] * 3, urls)
        self.assertNotIn('source-text', str(error.exception))

    def test_model_revision_and_batch_size_cannot_share_database(self):
        local = self.indexer()
        remote = OpenRouterAddIndexer('unused', transport=httpx.MockTransport(lambda _: httpx.Response(500)))
        changed = LocalAddIndexer('Qwen3.5-4B', 'test-revision-2')
        batched = self.indexer(batch_size=4)
        self.addCleanup(remote.close)
        self.addCleanup(changed.close)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'memory.db'
            MemoryStore(path, FakeEncoder(), add_indexer=local)
            MemoryStore(path, FakeEncoder(), add_indexer=self.indexer())
            for other in (remote, changed, batched):
                with self.assertRaisesRegex(ValueError, 'different model'):
                    MemoryStore(path, FakeEncoder(), add_indexer=other)
        self.assertEqual('openrouter/openai/gpt-4o-mini:source-span-ids-v1', remote.identity)

    def test_environment_switch_requires_no_openrouter_key_for_local(self):
        env = {'AE_ADD_INDEXER': '1', 'AE_ADD_LLM_BACKEND': 'local',
               'AE_LOCAL_LLM_MODEL': 'Qwen3.5-4B', 'AE_LOCAL_LLM_REVISION': 'revision-1'}
        with patch.dict(os.environ, env, clear=True):
            model = add_indexer_from_env()
            self.addCleanup(model.close)
            self.assertIsInstance(model, LocalAddIndexer)
            self.assertEqual(2, model.batch_size)
        with patch.dict(os.environ, {**env, 'AE_ADD_LLM_BACKEND': 'openrouter'}, clear=True):
            with self.assertRaisesRegex(ValueError, 'OPENROUTER_API_KEY'):
                add_indexer_from_env()
        with patch.dict(os.environ, {**env, 'AE_ADD_LLM_BACKEND': 'typo'}, clear=True):
            with self.assertRaisesRegex(ValueError, 'AE_ADD_LLM_BACKEND'):
                add_indexer_from_env()

    def test_preflight_reports_local_profile_and_requires_revision(self):
        env = {k: v for k, v in SETTINGS.items() if k != 'OPENROUTER_API_KEY'}
        env.update(AE_ADD_LLM_BACKEND='local', AE_LOCAL_LLM_MODEL='Qwen3.5-4B',
                   AE_LOCAL_LLM_REVISION='revision-1')
        with patch.dict(os.environ, env, clear=True):
            report = preflight.configuration_report()
        self.assertTrue(report['ready_for_live_probe'])
        self.assertEqual('Qwen3.5-4B', report['add_llm'])
        self.assertFalse(report['standard_academic_model_profile'])
        env.pop('AE_LOCAL_LLM_REVISION')
        with patch.dict(os.environ, env, clear=True):
            report = preflight.configuration_report()
        self.assertFalse(report['ready_for_live_probe'])
        self.assertIn('AE_LOCAL_LLM_REVISION', report['missing_environment'])

    def test_health_exposes_actual_local_model_and_search_returns_original(self):
        with tempfile.TemporaryDirectory() as tmp:
            model = self.indexer()
            store = MemoryStore(Path(tmp) / 'memory.db', FakeEncoder(), add_indexer=model)
            app.dependency_overrides[get_store] = lambda: store
            self.addCleanup(app.dependency_overrides.clear)
            with patch.dict(os.environ, {'MEMORY_API_KEY': 'local-test'}, clear=True):
                client = TestClient(app)
                health = client.get('/health').json()
                self.assertEqual('Qwen3.5-4B', health['llm'])
                self.assertEqual('local', health['llm_provider'])
                headers = {'X-Api-Key': 'local-test'}
                add = client.post('/add', headers=headers, json={
                    'user_id': 'u', 'request_id': 'r', 'session_id': 's',
                    'messages': [{'role': 'user', 'content': 'Luna likes the blue wand.'}]})
                self.assertEqual(200, add.status_code)
                hits = client.post('/search', headers=headers, json={
                    'user_id': 'u', 'query': 'Luna wand', 'top_k': 1}).json()['data']
                self.assertEqual('[user] Luna likes the blue wand.', hits[0]['content'])


if __name__ == '__main__':
    unittest.main()
