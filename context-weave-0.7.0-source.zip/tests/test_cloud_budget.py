import concurrent.futures
import json
from pathlib import Path
import tempfile
import unittest
import httpx
from adaptive_evidence.cloud_budget import CloudBudget,BudgetError,BudgetedClient,PROVIDER
from adaptive_evidence.add_indexer import OpenRouterAddIndexer,AddIndexerError

ENDPOINT='https://openrouter.ai/api/v1/chat/completions'
PAYLOAD={'model':'openai/gpt-4o-mini','max_tokens':1024,'store':False,'provider':PROVIDER,
         'messages':[{'role':'user','content':'synthetic only'}]}

class CloudBudgetTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'budget.sqlite3';self.budget=CloudBudget(self.path)

    def test_atomic_concurrent_reservations_and_restart(self):
        def reserve(_):
            try:return CloudBudget(self.path).reserve('test')
            except BudgetError:return None
        with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
            tokens=list(pool.map(reserve,range(80)))
        self.assertEqual(33,len([t for t in tokens if t]))
        self.assertEqual(.99,CloudBudget(self.path).summary()['held_or_spent_usd'])
        with self.assertRaises(BudgetError):self.budget.reserve('restart')
        with self.assertRaises(BudgetError):CloudBudget(self.path,'.99')

    def test_settlement_releases_unused_and_unknown_retained(self):
        a=self.budget.reserve('add');b=self.budget.reserve('search')
        self.budget.settle(a,{'usage':{'cost':.00100000001}})
        self.budget.settle(b,{'usage':{'cost':float('nan')}})
        summary=self.budget.summary()
        self.assertAlmostEqual(.031000001,summary['held_or_spent_usd'])
        self.assertEqual(1,summary['unknown_or_pending_requests'])
        with self.assertRaises(BudgetError):self.budget.settle(a,{'usage':{'cost':0}})

    def test_missing_invalid_costs_never_refund(self):
        for body in [None,{}, {'usage':{}}, {'usage':{'cost':True}}, {'usage':{'cost':-1}}, {'usage':{'cost':'oops'}}]:
            self.budget.settle(self.budget.reserve('test'),body)
        self.assertEqual(.18,self.budget.summary()['held_or_spent_usd'])

    def test_unexpected_overcharge_halts(self):
        token=self.budget.reserve('test')
        with self.assertRaises(BudgetError):self.budget.settle(token,{'usage':{'cost':.031}})
        self.assertTrue(self.budget.summary()['halted'])
        with self.assertRaises(BudgetError):self.budget.reserve('test')

    def test_unknown_network_outcome_keeps_reservation(self):
        def fail(req):raise httpx.ReadTimeout('test')
        with httpx.Client(transport=httpx.MockTransport(fail)) as raw:
            client=BudgetedClient(raw,self.budget,'test')
            with self.assertRaises(httpx.ReadTimeout):client.post(ENDPOINT,json=PAYLOAD)
        self.assertEqual(.03,self.budget.summary()['held_or_spent_usd'])

    def test_policy_checked_before_network(self):
        def fail(req):self.fail('Should never call network')
        with httpx.Client(transport=httpx.MockTransport(fail)) as raw:
            client=BudgetedClient(raw,self.budget,'test')
            for update in [{'model':'other'},{'max_tokens':2048},{'provider':{}},{'plugins':[]},{'store':True}]:
                with self.assertRaises(BudgetError):client.post(ENDPOINT,json={**PAYLOAD,**update})
        self.assertEqual(0,self.budget.summary()['requests'])

    def test_add_and_search_share_retries_budget(self):
        count=[]
        def handler(req):count.append(1);return httpx.Response(500)
        limited=CloudBudget(Path(self.tmp.name)/'small.sqlite3','.06')
        with httpx.Client(transport=httpx.MockTransport(handler)) as raw:
            BudgetedClient(raw,limited,'search').post(ENDPOINT,json=PAYLOAD)
        indexer=OpenRouterAddIndexer('fake',budget=limited,transport=httpx.MockTransport(handler),sleep=lambda _:None)
        self.addCleanup(indexer.close)
        with self.assertRaises(AddIndexerError):indexer.enrich(['synthetic source'])
        self.assertEqual(2,len(count));self.assertEqual(.06,limited.summary()['held_or_spent_usd'])

    def test_response_settled_even_if_add_output_invalid(self):
        def handler(req):return httpx.Response(200,json={'usage':{'cost':.002},'choices':[]})
        indexer=OpenRouterAddIndexer('fake',budget=self.budget,transport=httpx.MockTransport(handler),max_attempts=1)
        self.addCleanup(indexer.close)
        with self.assertRaises(AddIndexerError):indexer.enrich(['synthetic source'])
        self.assertEqual(.002,self.budget.summary()['confirmed_cost_usd'])

if __name__=='__main__':unittest.main()
