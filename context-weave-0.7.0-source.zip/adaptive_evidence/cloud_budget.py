"""Persistent, shared spending reservations for one bounded OpenRouter run.

No prompts, credentials or completions enter the ledger. Unknown outcomes keep
their full reservation, including timeouts and process death. Retries reserve
again. A fixed $0.03 reservation exceeds the maximum accepted text request:
128K input at $0.15/M plus <=1024 output at $0.60/M, with extra headroom.
"""
from contextlib import contextmanager
from decimal import Decimal, ROUND_CEILING
import json
import os
from pathlib import Path
import sqlite3
import time
import uuid

NANO = 1_000_000_000
RESERVATION = 30_000_000
PROVIDER = {'only':['openai'], 'allow_fallbacks':False,
            'require_parameters':True, 'data_collection':'deny',
            'max_price':{'prompt':0.15,'completion':0.60,'request':0}}

class BudgetError(RuntimeError):
    pass

class CloudBudget:
    def __init__(self, path, limit_usd='1'):
        limit=Decimal(str(limit_usd))
        if not limit.is_finite() or not 0 < limit <= 1:
            raise ValueError('Cloud budget must be positive and at most USD 1')
        self.limit=int(limit*NANO)
        self.path=str(Path(path).resolve())
        Path(self.path).parent.mkdir(parents=True,exist_ok=True)
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS policy (id INTEGER PRIMARY KEY CHECK(id=1), cap INTEGER NOT NULL, halted INTEGER NOT NULL DEFAULT 0)')
            db.execute('CREATE TABLE IF NOT EXISTS calls (id TEXT PRIMARY KEY, phase TEXT, created REAL, held INTEGER NOT NULL, actual INTEGER, state TEXT NOT NULL)')
            db.execute('INSERT OR IGNORE INTO policy(id,cap) VALUES(1,?)',(self.limit,))
            if db.execute('SELECT cap FROM policy WHERE id=1').fetchone()[0]!=self.limit:
                raise BudgetError('Persistent budget limit cannot be changed')

    @contextmanager
    def db(self):
        db=sqlite3.connect(self.path,timeout=30)
        try:
            db.execute('BEGIN IMMEDIATE')
            yield db
            db.commit()
        except BaseException:
            db.rollback();raise
        finally:
            db.close()

    def reserve(self,phase):
        with self.db() as db:
            cap,halted=db.execute('SELECT cap,halted FROM policy WHERE id=1').fetchone()
            used=db.execute('SELECT COALESCE(SUM(held),0) FROM calls').fetchone()[0]
            if halted or used+RESERVATION>cap:
                raise BudgetError('Shared cloud spending limit reached; no request sent')
            token=uuid.uuid4().hex
            db.execute('INSERT INTO calls VALUES(?,?,?,?,NULL,?)',(token,phase,time.time(),RESERVATION,'reserved'))
            return token

    def settle(self,token,body):
        usage=body.get('usage') if isinstance(body,dict) else None
        value=usage.get('cost') if isinstance(usage,dict) else None
        if isinstance(value,bool) or not isinstance(value,(str,int,float,Decimal)):
            return  # Missing or unknown charge retains the entire reservation.
        try: cost=Decimal(str(value))
        except Exception: return
        if not cost.is_finite() or cost<0:return
        actual=int((cost*NANO).to_integral_value(rounding=ROUND_CEILING))
        exceeded=False
        with self.db() as db:
            row=db.execute('SELECT held,state FROM calls WHERE id=?',(token,)).fetchone()
            if row is None or row[1]!='reserved':raise BudgetError('Invalid budget settlement')
            exceeded=actual>row[0]
            db.execute('UPDATE calls SET held=?,actual=?,state=? WHERE id=?',
                       (actual,actual,'settled',token))
            if exceeded:db.execute('UPDATE policy SET halted=1 WHERE id=1')
        if exceeded:raise BudgetError('Provider exceeded reserved charge; cloud calls halted')

    def summary(self):
        with self.db() as db:
            cap,halted=db.execute('SELECT cap,halted FROM policy WHERE id=1').fetchone()
            held,actual,calls,pending=db.execute("SELECT COALESCE(SUM(held),0),COALESCE(SUM(actual),0),COUNT(*),COALESCE(SUM(state='reserved'),0) FROM calls").fetchone()
            return {'cap_usd':cap/NANO,'held_or_spent_usd':held/NANO,'confirmed_cost_usd':actual/NANO,
                    'requests':calls,'unknown_or_pending_requests':pending,'halted':bool(halted)}

def budget_from_env():
    path=os.getenv('AE_CLOUD_BUDGET_DB')
    if not path:raise BudgetError('Persistent shared cloud budget path is required')
    return CloudBudget(path,os.getenv('AE_CLOUD_BUDGET_USD','1'))

class BudgetedClient:
    def __init__(self,client,budget,phase):
        self.client,self.budget,self.phase=client,budget,phase
    def close(self):self.client.close()
    def post(self,endpoint,*,json):
        # Only text-only, fixed-model, bounded-output requests may use this bound.
        if (endpoint!='https://openrouter.ai/api/v1/chat/completions'
            or json.get('model')!='openai/gpt-4o-mini'
            or type(json.get('max_tokens')) is not int or not 1<=json['max_tokens']<=1024
            or json.get('provider')!=PROVIDER or json.get('store') is not False
            or set(json)-{'model','temperature','max_tokens','messages','response_format','provider','store'}
            or any(not isinstance(m.get('content'),str) or set(m)!={'role','content'} for m in json['messages'])):
            raise BudgetError('Request does not satisfy fixed cloud cost policy')
        token=self.budget.reserve(self.phase)
        response=self.client.post(endpoint,json=json)
        if response.status_code==200:
            try:body=response.json()
            except (ValueError,TypeError):body=None
            self.budget.settle(token,body)
        return response
