"""GPT-4o-mini comparison using the v0.6.1 evidence algorithm and clipping.

The Qwen tokenizer is retained solely to keep internal excerpt and batching
boundaries comparable. It is NOT used for billing or cloud spending bounds.
"""
import hashlib
import json
import threading
import httpx
from .local_planner import LocalEvidencePlanner, LocalPlanningError, EXPAND, SELECT
from .cloud_budget import BudgetedClient, BudgetError, PROVIDER, budget_from_env
from .add_indexer import OpenRouterAddIndexer

class CloudEvidencePlanner(LocalEvidencePlanner):
    model='openai/gpt-4o-mini'

    def __init__(self,key,tokenizer_path,*,transport=None,budget=None):
        if not key:raise ValueError('OPENROUTER_API_KEY is required')
        super().__init__(tokenizer_path)
        self.client.close()
        self.endpoint=OpenRouterAddIndexer.endpoint
        self.client=BudgetedClient(httpx.Client(timeout=60,follow_redirects=False,
            headers={'Authorization':'Bearer '+key},transport=transport),budget or budget_from_env(),'search')
        self.slots=threading.BoundedSemaphore(4)
        self.identity='openrouter/gpt-4o-mini-evidence-v2-qwen-clipping:'+hashlib.sha256((EXPAND+SELECT).encode()).hexdigest()

    def request(self,field,data):
        instruction=EXPAND if field=='queries' else SELECT
        serialized=json.dumps(data,ensure_ascii=False,separators=(',',':'))
        if len(self.tokens(instruction))+len(self.tokens(serialized))>7200:
            raise LocalPlanningError('Planner token budget exceeded')
        with self.slots:
            with self.lock:self.calls+=1
            try:
                response=self.client.post(self.endpoint,json={
                    'model':self.model,'temperature':0,'max_tokens':384 if field=='ids' else 256,
                    'store':False,'provider':PROVIDER,'response_format':{'type':'json_object'},
                    'messages':[{'role':'system','content':instruction},{'role':'user','content':serialized}]})
                response.raise_for_status();body=response.json();choice=body['choices'][0]
                if body.get('model') not in OpenRouterAddIndexer.accepted_models or choice['finish_reason']!='stop':
                    raise ValueError('Unexpected model or incomplete output')
                parsed=json.loads(choice['message']['content'])
                if not isinstance(parsed,dict) or set(parsed)!={field} or not isinstance(parsed[field],list):
                    raise ValueError('Invalid schema')
                values=parsed[field]
                if field=='queries':
                    if len(values)>3 or any(not isinstance(v,str) or not v.strip() or len(v)>240 for v in values):
                        raise ValueError('Invalid queries')
                else:
                    allowed={m['id'] for m in data['memories']}
                    if len(values)>16 or any(type(v) is not int or v not in allowed for v in values):
                        raise ValueError('Unknown evidence ID')
                usage=body.get('usage',{})
                with self.lock:
                    self.prompt_tokens+=usage.get('prompt_tokens',0)
                    self.completion_tokens+=usage.get('completion_tokens',0)
                return list(dict.fromkeys(values))
            except (BudgetError,httpx.HTTPError,ValueError,KeyError,IndexError,TypeError,AttributeError):
                with self.lock:self.failures+=1
                raise LocalPlanningError('Cloud planner failed; use original evidence fallback') from None
