# Frozen local model runtime

This directory contains exact copies of the runtime Python files and launcher used by the tested local Qwen3.5-4B deployment. MODEL_MANIFEST.json records SHA-256 hashes, dependency versions and model revision. Paths in that manifest are relative to the original workspace; corresponding runtime code is reproduced with the same layout here. Model/tokenizer files are external and their original licenses apply. No weights or credentials are included.

The deployed environment uses Python 3.10, CUDA torch 2.11.0+cu128, Transformers 5.16.1, safetensors 0.8.0 and accelerate 1.14.0. It uses BF16, no thinking, greedy generation, 8192 input-token maximum, 1024 output-token maximum, 9 GiB GPU weight budget, 18 GiB CPU budget. The inherited JSON response_format is not grammar constrained; the memory client validates span IDs.

On the existing Windows workspace, competition/runs/start-context-weave-qwen.ps1 starts this runtime. To reproduce in this directory, install dependencies into models/.venv, put verified model files under models/Qwen3.5-4B, and run that launcher from PowerShell. The optional models/qwen35_runtime directory is a Python package overlay used by the original workstation; installing the same dependency versions in the venv is equivalent. It is not necessary to copy third-party libraries into the source repo.

The runtime is not an official evaluation runner. It listens on loopback port 18090 and never creates an AML job. Public Add/Search uses a separate authenticated API process and database.
