# Context Weave 0.4.0 candidate status

Updated 2026-10-08. Local backend: Qwen3.5-4B; switch-back backend: OpenRouter openai/gpt-4o-mini; embedding: text-embedding-v4. Actual model identity is reported and profiles cannot share a database.

58 regression tests passed. Real local model and embedding preflight passed. Two concurrent synthetic Adds, 32 chunks total, plus idempotence and original-source Search checks passed in 43.531 seconds. Full capacity and retrieval quality remain unmeasured.

At release preparation, official Smoke and Full for 0.4.0 have not run. Publication and separate /v040/ endpoint binding are prepared for Smoke. The frozen deployed 0.3.1 release remains separate; its official Smoke scored 53.64 on 46 items in 13 minutes. That result cannot be transferred to the local model.

Model eligibility follows the applicable competition division or organizer exception; preflight does not validate an exception. No account creation or official evaluation is automated by this candidate.
