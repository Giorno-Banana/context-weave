# Context Weave

Text memory service, version `0.4.0` candidate. Add supports an explicitly selected local model or OpenRouter GPT-4o-mini. Release preparation snapshot dated 2026-10-08; official Smoke and Full are not yet run for this version.

Submission contact: 秦天朗. Team: recursive roll. Repository: [Giorno-Banana/context-weave](https://github.com/Giorno-Banana/context-weave). Copyright: 王子铭; MIT license retained.

## Method

Add retains original text, role, session and timestamp, splitting sources into chunks of at most 1,000 characters with 120-character overlap. An LLM selects up to three integer IDs from deterministic original spans of at most 96 characters. The program validates those IDs and resolves them to original spans, which reinforce embedding and BM25 indexing. No generated text becomes evidence.

The default `openrouter` backend pins `openai/gpt-4o-mini` to OpenAI without fallback and retains the 0.3.1 request/prompt behavior. The optional `local` backend accepts an explicitly named loopback model, adds the JSON schema to the prompt for local server compatibility, and strictly validates the returned model and output. The existing Qwen3.5-4B installation was used for local verification. See [MODEL_PROFILES.md](MODEL_PROFILES.md) for configuration, limitations and switching instructions.

Bailian `text-embedding-v4` provides 1,024-dimensional L2-normalized document/query vectors. Search combines dense and BM25 rankings with reciprocal rank fusion and adjacent source windows. It returns original source passages, at most the requested top_k (maximum 100), within a 24,000-character context budget. The optional Search planner stays disabled. Answer and Eval remain the platform's responsibility.

## Reliability

Single-worker FastAPI and SQLite WAL retain per-request batch checkpoints, idempotence and atomic Add visibility. Failed calls return sanitized 503 responses without model fallback. Local profile identity includes model, revision and batch size; cloud and local profiles require separate databases. Provider/model identity is disclosed in `/health` and preflight reports.

## Validation

On 2026-10-08, 58 regression tests passed, followed by a real Qwen3.5-4B plus text-embedding-v4 synthetic preflight and two concurrent 16-chunk HTTP Add requests. Both completed; all 32 chunks were processed in 43.531 seconds wall time including retry and Search checks. These bounded checks do not demonstrate Full capacity or quality.

The frozen 0.3.1 release passed an official textual Smoke on 2026-10-08 with 53.64 over 46 items. That result is historical and does not certify this local-model candidate. Version 0.4.0 has no official Smoke or Full result.

## Run

Install `requirements.txt`, prepare private credentials from `env.example`, and select a profile as described in [OPERATIONS.md](OPERATIONS.md) and [MODEL_PROFILES.md](MODEL_PROFILES.md). `preflight.py` accepts repeated `--env-file` options; later files override earlier ones. Run `python -m unittest discover -s tests -v` for regression checks. Live probes call configured providers on synthetic data and do not submit official jobs.

The [published competition FAQ](https://agentmemories.ai/competition/) requires gpt-4o-mini for academic LLM components. Local use in that division needs an applicable organizer exception; configuration tools do not certify eligibility or create accounts. Always disclose the actual model and frozen configuration.

See [PROVENANCE.md](PROVENANCE.md), [SUBMISSION.md](SUBMISSION.md) and [LICENSE](LICENSE). The source bundle excludes credentials, private memories, model weights. The exact local model server source and runtime fingerprint are included under local_runtime/.
