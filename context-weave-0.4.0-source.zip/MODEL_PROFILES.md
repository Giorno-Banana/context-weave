# 模型切换：0.4.0 候选

Add 可在本地开放权重模型和 OpenRouter `openai/gpt-4o-mini` 之间显式选择。Embedding 仍为百炼 `text-embedding-v4`，Search 不调用 LLM。本地模式节省 Add 的云端 LLM 调用费用，仍有百炼、电脑电力和网络成本。

| 设置 | 本地配置 | OpenRouter 配置 |
|---|---|---|
| `AE_ADD_LLM_BACKEND` | `local` | `openrouter` |
| 实际 Add 模型 | 本次验证为 `Qwen3.5-4B` | `openai/gpt-4o-mini` |
| 地址 | 本机 `/v1/chat/completions` | 固定 OpenRouter 地址 |
| 每批分块数 | 默认 2，可设置 1–8 | 8 |
| LLM 并发 | 默认 1 | 默认 4 |
| 每次上游请求超时 | 180 秒 | 60 秒 |
| 默认最多尝试 | 3 | 3 |
| 数据 | 独立本地模型数据库 | 独立 GPT 数据库 |

## 配置与运行

基础私有 `.env` 存储服务鉴权及百炼配置。复制 `env.local.example` 为 `local.env`，填写实际服务名称、loopback 地址以及 `AE_LOCAL_LLM_REVISION`。revision 应对应固定权重、tokenizer、运行代码、依赖版本及生成配置的哈希或不可变版本；模型文件或这些设置变化后必须更新 revision。本机已经对这些内容生成 SHA-256 清单。

先启动兼容 Chat Completions 的本地模型服务，再执行：

```powershell
python preflight.py --env-file .env --env-file local.env --live
.\start_local.ps1 -Port 18082 -EnvFile @('.env','local.env') -PythonPath 'C:\path\to\python.exe'
```

本次验证复用了工作区已有的 Qwen3.5-4B 权重及 Transformers GPU 运行环境，BF16、关闭 thinking，串行生成；服务位于 `127.0.0.1:18090`。该模型服务的源码快照与哈希清单位于 local_runtime/；第三方运行依赖和模型权重不随源代码包分发。本适配器的 `response_format` 同时附有提示词中的 schema，以兼容接受但未强制执行 JSON Schema 的本地服务；客户端始终检查模型名称、结束状态、完整 JSON 和编号范围。

切回 GPT 时停止当前候选服务，用单独的配置和数据库启动：

```powershell
python preflight.py --env-file .env --env-file env.openrouter.example
.\start_local.ps1 -Port 18082 -EnvFile @('.env','env.openrouter.example') -PythonPath 'C:\path\to\python.exe'
```

基础 `.env` 需有 `OPENROUTER_API_KEY`。更换模型必须重建索引；不能只改调用地址继续使用 Qwen 生成的索引。本地模型的 revision 或批大小变化也会拒绝复用已有数据库。源码版本、数据路径和运行配置应在每次官方评测前冻结。

本地请求不使用代理环境变量、不发送云 API Key、不跟随重定向，也不自动回退到收费模型。服务端 `/health` 如实显示实际 Add 模型、provider 和索引身份；它不是上游容量或赛事资格证明。

默认 Docker Compose 用于云端模型配置。容器中的 loopback 指容器自身，本地模式需要模型服务运行于同一网络命名空间，不能把宿主机模型的地址直接照搬进去。当前验证使用 Windows 原生运行，未验证 Docker 本地模型部署。

## 验证与评测边界

2026-10-08：58 项回归测试通过；Qwen 与百炼真实链路预检通过。两个并发合成 Add 共 32 个约 940 字符分块，整轮写入、重试和检索耗时 43.531 秒，无失败或跨用户混淆；Search 返回原文，重试约 0–0.016 秒。该小规模测试不证明 Full 容量或成绩。初始平台 Add 并发建议 1，验证长请求后再调整，不能直接沿用云端配置的 16。

本发布准备记录写入时，0.4.0 尚未进行官方 Smoke 或 Full。计划以独立 /v040/ 路径接入公网，保留根路径的 0.3.1 服务。原 0.3.1 官方 Smoke 53.64 分不属于本地模型版本。

[公开赛事 FAQ](https://agentmemories.ai/competition/)要求学术榜 LLM 组件使用 gpt-4o-mini。若依据主办方个别授权采用本地模型，提交材料仍应披露实际模型和配置，并按主办方批准的适用范围操作；本代码不会把 Qwen 标为 GPT，也不会创建账号或触发评测。
