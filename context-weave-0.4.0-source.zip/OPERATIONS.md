# 运行与复现：Context Weave 0.4.0

需要 Python 3.10+。安装 `requirements.txt`，准备私有 `.env`，保持百炼 `text-embedding-v4`、`AE_ADD_INDEXER=1`、`AE_PLANNER=0`。Add 的云端/本地模式、启动及切换命令见 [MODEL_PROFILES.md](MODEL_PROFILES.md)。使用两个配置文件时，先加载基础凭证文件，再加载模型配置文件。

Windows 启动器默认监听 `127.0.0.1:18082`；通过 `-PythonPath` 指定解释器，通过 `-EnvFile` 传入按顺序加载的文件数组。必须配置独立 `AE_DATABASE`，相对数据路径以本仓库为基准。启动器不设置自启动，不修改公网代理；退出启动器会停止服务。评测时电脑需保持通电、联网、不休眠。

```powershell
python -m unittest discover -s tests -v
python preflight.py --env-file .env --env-file local.env
python preflight.py --env-file .env --env-file local.env --live --output runs/live-probe.json
```

默认 preflight 离线；`--live` 使用临时数据库和合成数据调用配置中的模型与百炼。百炼仍有用量费用。Qwen 模式不调用 OpenRouter；GPT 模式会有相应费用。报告不包含 Key 或对话内容。

`AE_ADD_LLM_MAX_REQUESTS` 和 `AE_EMBEDDING_MAX_REQUESTS` 为包含重试的进程内次数上限；0 为不限，重启会重置。模型错误不会触发云端回退或跳过 LLM。API 使用单 worker，SQLite 的私有分批检查点在重启后仍可复用；完整 Add 提交前不暴露中间数据。

改模型、revision、提示词或索引方法后使用新版本及数据库。官方任务开始后冻结配置，不在运行途中切换。0.4.0 尚未发布到公网或跑官方 Smoke/Full，0.3.1 的原服务和数据库由原启动器继续管理。官方数据仅限当前评测用途，按赛事要求清理到期数据及备份。
