# Candidate deployment notes: Context Weave 0.4.0

Release preparation, 2026-10-08. Source publication, separate version binding and official Smoke are the next steps. The root public endpoint remains frozen 0.3.1; this version uses /v040/.

| Field | Candidate value |
|---|---|
| Track | Textual |
| Intended division | Academic / Open-source Methods, subject to applicable organizer permission for the actual local model |
| Contact / team | 秦天朗 / recursive roll |
| Copyright / license | 王子铭 / MIT |
| Add model in tested local profile | Qwen3.5-4B, local BF16 Transformers runtime, thinking disabled |
| Alternative Add profile | OpenRouter openai/gpt-4o-mini, OpenAI only, no fallback |
| Embedding | text-embedding-v4, 1024 dimensions |
| Local API | 127.0.0.1:18082; authenticated Add/Search |
| Local model | 127.0.0.1:18090; two chunks per call, LLM concurrency 1 |
| Initial proposed platform Add concurrency | 1, subject to further capacity checks |
| Fixed source commit | Use the full SHA of the published 0.4.0 release |
| Public Add / Search | https://wzm.tail36b9f2.ts.net/v040/add and /v040/search |
| Model revision | sha256-8267024d0feba058a3f26e5602a829432fe3d1da84bad553f98985b004f047d8 |
| Official Smoke / Full for this version | Not run |

Record the actual weights/runtime fingerprint and source commit when freezing a run. Do not reuse Qwen indexes for GPT or change model while a run is active. A new configuration needs its own verification. See MODEL_PROFILES.md for measured checks and public-rule limitations, README for method semantics, and PROVENANCE.md for authorship and references.
