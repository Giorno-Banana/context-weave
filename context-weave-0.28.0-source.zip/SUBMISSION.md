# Context Weave / SourceTrail 0.28.0

Textual Memory; open-source method release. Current supplied evaluation account displays Adaptive Evidence. This release uses no generative Add/Search model; embedding is text-embedding-v4, 1024 dimensions. Generative Answer belongs to the AML evaluator. All model choices are disclosed; this document does not claim a model-rule exemption.

The source implements synchronous authenticated Add/Search, request-id idempotency, user isolation, immediate retrieval after Add, and persistent storage. Add/Search concurrency is 16/16. Search uses stem_window with a 24,000-character budget. README.md describes reproduction and public diagnostic limits. No official score is claimed before a completed run.

Original author/copyright: 王子铭 (Giorno-Banana), MIT. See PROVENANCE.md for method sources. No upstream code or prompt was copied for 0.28.0.
