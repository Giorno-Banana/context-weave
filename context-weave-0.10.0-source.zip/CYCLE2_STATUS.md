# Candidate0.10.0 status

Actual model: local Qwen3.5-4B; runtime0.4.2; embedding text-embedding-v4. No official result exists yet. Full is not authorized. Read README.md and EXPERIMENT.json for configuration, public-study limitations and participant-reported local-model permission. Other old experiment reports are historical and do not evaluate this candidate.
