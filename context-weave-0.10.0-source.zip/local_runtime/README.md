# Active runtime0.4.2

Use the supervised Transformers Qwen3.5-4B runtime and MODEL_MANIFEST.json. The1024-token chunked-prefill threshold was tested for long-context stability; runtime042 is not numerically identical to041. Legacy VALIDATION/SEARCH_VALIDATION artifacts describe earlier runtime tests and do not score this candidate. The historical9B llama.cpp manifest and launcher are excluded from this release.
