"""Fingerprint local weights, serving source, and fixed generation settings."""
import argparse
import hashlib
import json
from pathlib import Path


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    paths = sorted((root / 'competition').glob('*.py')) + sorted((root / 'models').glob('*.py'))
    paths.append(root / 'start_supervised.ps1')
    files = {p.relative_to(root).as_posix(): sha256(p) for p in paths}
    weights = {}
    for name in ('chat_template.jinja', 'config.json', 'merges.txt', 'model.safetensors.index.json',
                 'model.safetensors-00001-of-00002.safetensors', 'model.safetensors-00002-of-00002.safetensors',
                 'tokenizer.json', 'tokenizer_config.json', 'vocab.json'):
        weights[name] = sha256(args.model_dir / name)
    manifest = dict(model='Qwen3.5-4B', runtime_version='0.4.2', files=files, external_weights=weights,
        packages=dict(torch='2.11.0+cu128', transformers='5.16.1', safetensors='0.8.0', accelerate='1.14.0'),
        configuration=dict(dtype='bfloat16', thinking=False, temperature=0, input_tokens=8192,
            output_tokens=1024, gpu_weight_budget='9GiB', cpu_weight_budget='18GiB',
            prefill_chunk_size=1024, chunked_prefill_above=1024,
            generation_timeout=90, cancellation_grace=5, request_timeout=150,
            startup_timeout=90, queue_limit=16, workers=1))
    manifest['revision'] = 'sha256-' + hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    (root / 'MODEL_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    profile = (root / 'profile.txt').read_text(encoding='utf-8').splitlines()
    profile = [f'AE_LOCAL_LLM_REVISION={manifest["revision"]}' if line.startswith('AE_LOCAL_LLM_REVISION=') else line for line in profile]
    (root / 'profile.txt').write_text('\n'.join(profile) + '\n', encoding='utf-8')
    print(manifest['revision'])


if __name__ == '__main__':
    main()
