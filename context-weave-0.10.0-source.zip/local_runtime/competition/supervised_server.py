"""Loopback-only OpenAI adapter with a cancellable, disposable GPU worker."""
from __future__ import annotations

import argparse
import os
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field

from model_worker import worker_main
from runtime_control import Limits, RuntimeFailure, Supervisor

MODEL = os.environ.get('LOCAL_MODEL_NAME', 'Qwen3.5-4B')


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    model: str | None = None
    messages: list[Message] = Field(min_length=1, max_length=256)
    temperature: float = Field(default=0, ge=0, le=2)
    response_format: dict | None = None
    max_tokens: int = Field(default=256, ge=1, le=4096)


class BatchChatRequest(BaseModel):
    requests: list[ChatRequest] = Field(min_length=1, max_length=8)


def configured_limits():
    return Limits(generation=float(os.environ.get('LOCAL_GENERATION_TIMEOUT', '90')),
                  grace=float(os.environ.get('LOCAL_CANCEL_GRACE', '5')),
                  request=float(os.environ.get('LOCAL_REQUEST_TIMEOUT', '150')),
                  startup=float(os.environ.get('LOCAL_STARTUP_TIMEOUT', '90')),
                  queue=int(os.environ.get('LOCAL_QUEUE_LIMIT', '16')))


def create_app(worker=worker_main, limits=None):
    control = Supervisor(worker, limits or configured_limits())

    @asynccontextmanager
    async def lifespan(app):
        await control.start()
        try:
            yield
        finally:
            await control.close()

    app = FastAPI(title='Context Weave supervised local model', lifespan=lifespan)
    app.state.supervisor = control

    @app.get('/health')
    async def health():
        return dict(**control.health(), model=MODEL, device=os.environ.get('LOCAL_DEVICE', 'cuda:0'),
                    runtime_version='0.4.2', max_input_tokens=int(os.environ.get('LOCAL_MAX_INPUT_TOKENS', '8192')),
                    max_output_tokens=int(os.environ.get('LOCAL_MAX_OUTPUT_TOKENS', '1024')),
                    max_structured_output_tokens=int(os.environ.get('LOCAL_MAX_STRUCTURED_OUTPUT_TOKENS', '1024')))

    @app.get('/v1/models')
    async def models():
        return {'object': 'list', 'data': [{'id': MODEL, 'object': 'model', 'owned_by': 'local'}]}

    async def infer(requests, http_request):
        if any(r.model not in (None, MODEL) for r in requests):
            raise HTTPException(400, 'model_mismatch')
        if len({(r.max_tokens, r.temperature, bool(r.response_format)) for r in requests}) != 1:
            raise HTTPException(400, 'batch_settings_mismatch')
        try:
            data = await control.submit({'requests': [r.model_dump() for r in requests]}, http_request.is_disconnected)
        except RuntimeFailure as error:
            raise HTTPException(error.status, error.code) from None
        replies = []
        for answer, prompt, completion in data['rows']:
            replies.append(dict(id='chatcmpl-' + uuid.uuid4().hex, object='chat.completion',
                created=int(time.time()), model=MODEL,
                choices=[{'index': 0, 'message': {'role': 'assistant', 'content': answer},
                          'finish_reason': 'length' if completion >= data['limit'] else 'stop'}],
                usage=dict(prompt_tokens=prompt, completion_tokens=completion, total_tokens=prompt+completion),
                local_metrics=dict(data['metrics'])))
        return {'responses': replies, 'local_metrics': data['metrics']}

    @app.post('/v1/chat/completions')
    async def chat(body: ChatRequest, request: Request):
        return (await infer([body], request))['responses'][0]

    @app.post('/v1/chat/completions/batch')
    async def batch(body: BatchChatRequest, request: Request):
        return await infer(body.requests, request)

    return app


if __name__ == '__main__':
    import uvicorn
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', choices=['127.0.0.1', '::1'], default='127.0.0.1')
    parser.add_argument('--port', type=int, default=18091)
    args = parser.parse_args()
    uvicorn.run(create_app(), host=args.host, port=args.port, workers=1)
