"""Bound long-input prefill memory without truncating the supplied evidence."""
import full_qa_server as adapter

server = adapter.server
original_load = server.load_model


def load_model():
    original_load()
    model = server.state["model"]
    original_generate = model.generate

    def generate(*args, **kwargs):
        ids = kwargs.get("input_ids")
        if ids is not None and ids.shape[-1] > 1024:
            kwargs["prefill_chunk_size"] = 1024
            kwargs["disable_compile"] = True
        return original_generate(*args, **kwargs)

    model.generate = generate
    print("v4 runtime: prefill chunks 1024 above 1024 input tokens; short inputs unchanged", flush=True)


server.load_model = load_model


if __name__ == "__main__":
    server.main()
