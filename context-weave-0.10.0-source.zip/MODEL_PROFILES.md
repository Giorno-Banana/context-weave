# Model profiles

The active 0.10.0 profile is local Qwen3.5-4B on the supervised runtime 0.4.2 at port 18095. Its exact fingerprint is recorded in `local_runtime/MODEL_MANIFEST.json`. Use the top-level `env.local.example`, not the historical runtime profile. Add indexing and Search planning both use this local model; embedding uses text-embedding-v4. No OpenRouter fallback is enabled.

The separate cloud implementation and `env.openrouter.example` remain available as historical optional code. They are not part of this candidate's configuration and must not be enabled without separate authorization and a separate database. Never reuse stored vectors or pending Add checkpoints across differing model/indexer identities.

No official result exists for 0.10.0 yet. Best prior complete official Smoke: 61.77 for 0.6.1. Local-model eligibility is based on participant-reported organizer permission, not independently verified by this repository.
