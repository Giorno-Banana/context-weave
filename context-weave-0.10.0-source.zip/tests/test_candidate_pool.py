import unittest
from dataclasses import replace
import test_contract as fixtures
from adaptive_evidence.local_planner import EvidenceSearch


class CandidatePoolTests(unittest.TestCase):
    setUp = fixtures.ContractTests.setUp
    tearDown = fixtures.ContractTests.tearDown
    add = fixtures.ContractTests.add

    def test_selector_sees_sources_beyond_final_context_budget(self):
        self.store.config = replace(self.store.config, context_chars=200)
        for number in range(20):
            self.add(request=str(number), content=f'Archive record {number}: ' + 'ordinary catalog entry ' * 5)
        self.add(user='other', request='private', content='Archive private secret')
        baseline = self.store.search(user_id='u', query='archive')
        candidates = self.store.candidate_hits(user_id='u', query='archive')
        self.assertEqual(len(candidates), 20)
        self.assertGreater(len(candidates), len(baseline))
        target = next(h for h in reversed(candidates) if h['id'] not in {b['id'] for b in baseline})
        captured = []

        class Planner:
            def expand(self, *args):
                return []

            def select(self, query, options, pool):
                captured.extend(pool)
                return [next(i for i, hit in enumerate(pool, 1) if hit['id'] == target['id'])]

        result = EvidenceSearch(self.store, Planner(), context_chars=200).search(user_id='u', query='archive', top_k=1)
        self.assertEqual(result[0]['content'], target['content'])
        self.assertLessEqual(len(captured), 128)
        self.assertNotIn('private secret', str(captured))
        self.assertLessEqual(sum(len(h['content']) for h in result), 200)

    def test_internal_candidate_limit_is_bounded_and_validated(self):
        self.add(content='Archive statement')
        for limit in (False, 0, 129):
            with self.assertRaises(ValueError):
                self.store.candidate_hits(user_id='u', query='archive', limit=limit)
        self.assertEqual(self.store.candidate_hits(user_id='missing', query='archive'), [])
        self.assertEqual(len(self.store.candidate_hits(user_id='u', query='archive', limit=1)), 1)
