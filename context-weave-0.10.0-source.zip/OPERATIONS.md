# Operations for 0.10.0

Run the supervised Qwen3.5-4B runtime on loopback port 18095 with the packages, weights and runtime fingerprint in `local_runtime/MODEL_MANIFEST.json`. Configure the API with private credentials followed by the new `env.local.example` profile. The tested API port is 18097. Use a fresh database for this version. The older `local_runtime/profile.txt` is historical; the top-level `env.local.example` is the active API profile.

Add uses local source-span ID indexing, batch size 2 and model concurrency 1. Search uses the local evidence planner with expansion enabled, a bounded 128-source candidate pool, 12,000-character selected output and 24,000-character fallback. The embedding service is text-embedding-v4. Add/Search require authentication; the model server remains loopback only. Local model failures never trigger cloud fallback.

Before an official Smoke, finish unit tests, synthetic semantic and network checks, concurrent requests, source and credential scans, publication and archive verification. Freeze source, configuration and runtime throughout evaluation. Report actual model, runtime, all fallbacks and complete results. Do not inspect private benchmark payloads. No Full or additional OpenRouter calls are authorized for this candidate.
