"""Bounded, non-generative passage relevance scoring over original sources.

No question generation, answer generation, labels, or memory rewriting. The
encoder sees only the ordinary Search query/options and the user's own text.
"""
from __future__ import annotations

import math
import re
import hashlib
import json
import threading
import os
import unicodedata
from pathlib import Path


class RerankError(RuntimeError):
    """Safe operational error; never includes query or memory contents."""


class LocalCrossEncoder:
    def __init__(self, model_path, *, device='cuda', batch_size=8, max_length=512):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        self.path = Path(model_path).resolve()
        if not self.path.is_dir():
            raise RerankError('Reranker model directory is unavailable')
        manifest = json.loads(Path(__file__).with_name('reranker_manifest.json').read_text())
        for name, expected in manifest['sha256'].items():
            path = self.path/name
            if not path.is_file():
                raise RerankError('Reranker model files are incomplete')
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda:stream.read(1024*1024),b''):
                    digest.update(block)
            if digest.hexdigest() != expected:
                raise RerankError('Reranker model checksum mismatch')
        if not 1 <= batch_size <= 32 or not 128 <= max_length <= 8192:
            raise ValueError('Invalid reranker resource limits')
        if device == 'cuda' and not torch.cuda.is_available():
            raise RerankError('Configured reranker GPU is unavailable')
        self.device, self.batch_size, self.max_length = device, batch_size, max_length
        self.identity = manifest['identity']
        torch.set_num_threads(2)
        self.lock = threading.Lock()
        self.tokenizer = AutoTokenizer.from_pretrained(self.path, local_files_only=True, trust_remote_code=False)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            self.path, local_files_only=True, trust_remote_code=False, use_safetensors=True,
            torch_dtype=torch.float16 if device == 'cuda' else torch.float32).to(device).eval()

    def score(self, query, documents, *, options=None):
        import torch
        if not documents:
            return []
        if len(documents) > 96:
            raise ValueError('Too many reranker candidates')
        # This bound affects the scoring view only. Returned source spans and
        # the full query used in lexical/dense retrieval are never shortened.
        view_budget = self.max_length // 2 - 32
        query_ids = self.tokenizer.encode(query, add_special_tokens=False)
        if options:
            choice_budget = max(1, view_budget // (2 * len(options)))
            query_budget = view_budget - choice_budget * len(options)
            parts = [self.tokenizer.decode(query_ids[:query_budget], skip_special_tokens=True)]
            for option in options:
                option_ids = self.tokenizer.encode(option, add_special_tokens=False)
                parts.append(self.tokenizer.decode(option_ids[:choice_budget], skip_special_tokens=True))
            query_view = '\n'.join(parts)
        else:
            query_view = self.tokenizer.decode(query_ids[:view_budget], skip_special_tokens=True)
        scores = []
        try:
            with self.lock, torch.inference_mode():
                for offset in range(0, len(documents), self.batch_size):
                    batch = documents[offset:offset+self.batch_size]
                    inputs = self.tokenizer([query_view]*len(batch), batch, padding=True,
                                            truncation='only_second', max_length=self.max_length,
                                            return_tensors='pt').to(self.device)
                    scores.extend(self.model(**inputs).logits.float().reshape(-1).cpu().tolist())
        except Exception as exc:
            raise RerankError('Local relevance scoring failed') from exc
        if len(scores) != len(documents) or not all(math.isfinite(v) for v in scores):
            raise RerankError('Invalid relevance scores')
        return scores


def rerank_order(index, ranked, query, options, scorer, *, weight, limit=96, documents=None):
    """Fuse stable RRF ranks, preserving the best original hit and the tail.

    No score calibration against benchmark labels. A bounded cross-encoder
    rank complements lexical/dense ranks; the original best hit is protected.
    """
    if scorer is None:
        raise RerankError('A non-generative reranker is required for this mode')
    if not 0 <= weight <= 1 or not 1 <= limit <= 96:
        raise ValueError('Invalid rerank configuration')
    pool = list(ranked[:limit])
    if len(pool) <= 1 or weight == 0:
        return list(ranked)
    # Equal per-option scoring-view token budgets avoid clipping later options
    # merely because they occurred later in the caller's list. No option is
    # selected, stored, or rewritten in the returned memory evidence.
    views = [index.rows[i]['content'] for i in pool] if documents is None else documents
    if len(views) != len(pool):
        raise RerankError('Invalid contextual scoring views')
    scores = scorer.score(query, views, options=(options or [])[:12])
    if len(scores) != len(pool) or not all(math.isfinite(float(v)) for v in scores):
        raise RerankError('Invalid relevance scores')
    cross_order = sorted(range(len(pool)), key=lambda p: (-scores[p], p))
    cross_ranks = {p: rank for rank, p in enumerate(cross_order, 1)}
    fused = [(1-weight)/(60+p+1) + weight/(60+cross_ranks[p]) for p in range(len(pool))]
    protected = min(3, len(pool))
    order = sorted(range(protected, len(pool)), key=lambda p: (-fused[p], p))
    return pool[:protected] + [pool[p] for p in order] + list(ranked[len(pool):])


def contextual_views(index, pool):
    """Center-first relevance views with bounded, verified local turn context.

    Only the classifier sees these views. Returned memory spans remain literal.
    Adjacency must come from the existing index and the same Add/session.
    """
    result=[]
    for i in pool:
        row=index.rows[i]
        parts=[row['content']]
        for j in getattr(index,'neighbors',{}).get(i,[]):
            if j==i or not 0<=j<len(index.rows):continue
            adjacent=index.rows[j]
            if not all(key in row and row[key]==adjacent.get(key) for key in ('session_id','request_id')):continue
            if abs(int(row.get('position',0))-int(adjacent.get('position',0)))>1:continue
            parts.append('Adjacent '+str(adjacent.get('role',''))[:32]+': '+adjacent['content'][:512])
            if len(parts)==3:break
        result.append('\n'.join(parts))
    return result


_scorer = None
_load_lock = threading.Lock()


SPEAKER_PREFIX = re.compile(r"^\s*(?:\*\*)?([\w .'-]{1,32})(?:\*\*)?:\s",re.UNICODE)
GENERIC_LABELS = {'user','assistant','system','human','ai','bot','context','question','answer','note','notes','summary','topic','title'}


def named_transcript(rows):
    sample=rows[:200]
    if len(sample)<8:return False
    labels=[]
    for row in sample:
        match=SPEAKER_PREFIX.match(row['content'])
        if match and (name:=match.group(1).strip().casefold()) not in GENERIC_LABELS:
            labels.append(name)
    return len(labels)*2>=len(sample) and len(set(labels))>=2


def conversation_order(index, ranked, query):
    global _scorer
    # Contextual user/assistant relevance is applied only to actual dyadic dialogs.
    # Notes and multiparty transcripts keep the original evidence ordering.
    roles={row.get('role','').casefold() for row in index.rows}
    if not {'user','assistant'} <= roles or named_transcript(index.rows) or any(row.get('timestamp') is None for row in index.rows):
        return list(ranked)
    if len(ranked) <= 3:
        return list(ranked)
    documents = contextual_views(index, ranked[:64])
    with _load_lock:
        if _scorer is None:
            path = os.environ.get('AE_RERANKER_MODEL')
            if not path:
                raise RerankError('Configure the pinned local relevance model directory')
            _scorer = LocalCrossEncoder(path, device='cuda', batch_size=8, max_length=512)
    return rerank_order(index,ranked,query,None,_scorer,weight=.5,limit=64,documents=documents)
