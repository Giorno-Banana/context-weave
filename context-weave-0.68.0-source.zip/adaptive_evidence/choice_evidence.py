"""Pretrained symmetric relevance ranks, never predicted answer labels."""
import math
import os
import threading
import numpy as np
from .cross_encoder import LocalCrossEncoder, contextual_views, RerankError

POLICIES={'choice_m3_light':(.15,3),'choice_m3_moderate':(.25,3),'choice_m3_anchors':(.25,6)}
CHOICE_MODES=set(POLICIES)
_scorer=None
_lock=threading.Lock()

def scorer():
    global _scorer
    with _lock:
        if _scorer is None:
            path=os.environ.get('AE_RERANKER_MODEL')
            if not path:raise RerankError('Configure the pinned local relevance model')
            _scorer=LocalCrossEncoder(path,device='cuda',batch_size=8,max_length=512)
    return _scorer

def relevance_order(index,ranked,query,options,mode,model):
    pool=list(ranked[:64])
    if len(pool)<=3:return list(ranked)
    weight,protected=POLICIES[mode]
    choices=sorted(set(options))[:12]
    if not choices:return list(ranked)
    documents=contextual_views(index,pool)
    streams=[None]
    support=np.zeros(len(pool),dtype=np.float64)
    for choices_view in streams:
        values=model.score(query,documents,options=choices_view)
        if len(values)!=len(pool) or not all(math.isfinite(float(v)) for v in values):
            raise RerankError('Invalid option relevance scores')
        order=sorted(range(len(pool)),key=lambda i:(-values[i],i))
        ranks=np.empty(len(pool),dtype=np.int64);ranks[order]=np.arange(len(pool))+1
        support=np.maximum(support,1.0/(60+ranks))
    # Original evidence retains75-85% of the RRF, and its first3or6 anchors
    # are protected. Every option receives equal scoring-view treatment.
    fused=(1-weight)/(60+np.arange(1,len(pool)+1))+weight*support
    protected=min(protected,len(pool))
    order=sorted(range(protected,len(pool)),key=lambda i:(-fused[i],i))
    return pool[:protected]+[pool[i] for i in order]+list(ranked[len(pool):])

def rank_choices(index,ranked,query,options,mode):
    if not options or len(ranked)<=3:return list(ranked)
    return relevance_order(index,ranked,query,options,mode,scorer())
