from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
from adaptive_evidence.core import MemoryStore
from adaptive_evidence.choice_evidence import CHOICE_MODES,POLICIES,relevance_order
from adaptive_evidence.cross_encoder import RerankError
from test_contract import FakeEncoder

class StableRelevanceTests(unittest.TestCase):
    def index(self,n=80):return SimpleNamespace(rows=[{'content':'Synthetic source '+str(i)} for i in range(n)],neighbors={})

    def test_open_inputs_and_scope_are_exact(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=MemoryStore(Path(tmp)/'memory.db',FakeEncoder())
            store.add(user_id='u',request_id='r',session_id='s',messages=[{'role':'user','content':'The cobalt unit needs a dry seal.'}])
            original=store.search(user_id='u',query='cobalt seal',mode='query_document_evidence')
            for mode in CHOICE_MODES:
                self.assertEqual(store.search(user_id='u',query='cobalt seal',mode=mode),original)
                self.assertEqual(store.search(user_id='other',query='cobalt',options=['dry','wet'],mode=mode),[])

    def test_each_declared_anchor_and_tail_are_protected(self):
        class Model:
            def score(self,q,docs,options=None):return list(range(len(docs)))
        for mode,(_,protected) in POLICIES.items():
            result=relevance_order(self.index(),list(range(80)),'q',['one','two'],mode,Model())
            self.assertEqual(result[:protected],list(range(protected)))
            self.assertEqual(result[64:],list(range(64,80)));self.assertEqual(sorted(result),list(range(80)))

    def test_scoring_is_query_only_and_option_symmetric(self):
        class Model:
            def __init__(self):self.calls=[]
            def score(self,q,docs,options=None):self.calls.append(options);return list(range(len(docs)))
        for mode in CHOICE_MODES:
            a=Model();b=Model()
            x=relevance_order(self.index(),list(range(80)),'q',['alpha','beta'],mode,a)
            y=relevance_order(self.index(),list(range(80)),'q',['beta','alpha','beta'],mode,b)
            self.assertEqual(x,y);self.assertEqual(a.calls,[None]);self.assertEqual(b.calls,[None])

    def test_invalid_classifier_output_fails_closed(self):
        class Model:
            def score(self,q,docs,options=None):return [float('nan')]*len(docs)
        with self.assertRaises(RerankError):relevance_order(self.index(),list(range(80)),'q',['one'],next(iter(CHOICE_MODES)),Model())

    def test_dominant_documents_bypass_new_fusion(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=MemoryStore(Path(tmp)/'memory.db',FakeEncoder())
            store.add(user_id='u',request_id='r',session_id='s',messages=[{'role':'user','content':'Cobalt manual requires dry seals. '*200}])
            original=store.search(user_id='u',query='cobalt seal',options=['dry','wet'],mode='query_document_evidence')
            with patch('adaptive_evidence.choice_evidence.rank_choices',side_effect=AssertionError('Document path must not change')):
                for mode in CHOICE_MODES:self.assertEqual(store.search(user_id='u',query='cobalt seal',options=['dry','wet'],mode=mode),original)

    def test_all_fusions_retain_the_majority_of_original_rank_weight(self):
        self.assertEqual(set(POLICIES.values()),{(.15,3),(.25,3),(.25,6)})
        self.assertTrue(all(0<w<=.25 and protected>=3 for w,protected in POLICIES.values()))

if __name__=='__main__':unittest.main()
