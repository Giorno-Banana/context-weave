import json
import threading
import unittest
import httpx
from adaptive_evidence.local_planner import LocalEvidencePlanner,LocalPlanningError
from adaptive_evidence.user_evidence import UserStatementPlanner


class SupplementProtocolTests(unittest.TestCase):
    def planner(self,cls,values):
        p=cls.__new__(cls)
        p.tokens=lambda s:list(s.encode())
        p.clip=lambda s,n:s[:n]
        p.slots=threading.BoundedSemaphore(2);p.lock=threading.Lock()
        p.calls=p.failures=p.prompt_tokens=p.completion_tokens=0
        p.endpoint='http://127.0.0.1:18095/v1/chat/completions'
        p.client=httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(200,json={
            'model':p.model,'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'ids':values})}}]})))
        self.addCleanup(p.close)
        return p

    def test_secondary_overcount_validates_all_then_bounds(self):
        p=self.planner(UserStatementPlanner,list(range(1,34)))
        data={'memories':[{'id':i} for i in range(1,34)]}
        self.assertEqual(p.request('ids',data),list(range(1,17)))
        primary=self.planner(LocalEvidencePlanner,list(range(1,34)))
        self.assertEqual(primary.request('ids',data),list(range(1,17)))

    def test_unknown_or_boolean_after_cutoff_rejects_entire_response(self):
        data={'memories':[{'id':i} for i in range(1,34)]}
        for tail in (999,True,'17'):
            p=self.planner(UserStatementPlanner,list(range(1,17))+[tail])
            with self.assertRaises(LocalPlanningError):p.request('ids',data)

