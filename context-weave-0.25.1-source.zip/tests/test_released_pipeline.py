import os
import unittest
from unittest.mock import patch
from adaptive_evidence import api

class ReleasedPipelineTests(unittest.TestCase):
    def test_api_routes_to_both_frozen_planners(self):
        primary,secondary,store=object(),object(),object()
        payload=api.Search(user_id='scope',query='Question',top_k=100)
        with patch.dict(os.environ,{'AE_LOCAL_EVIDENCE_SEARCH':'1'}), patch.object(api,'get_local_planner',return_value=primary), patch.object(api,'get_user_statement_planner',return_value=secondary), patch('adaptive_evidence.user_evidence.UserEvidenceSearch') as engine:
            engine.return_value.search.return_value=[{'id':'original','content':'original evidence','score':1.0}]
            result=api.search(payload,store=store)
            self.assertEqual(engine.call_args.args,(store,primary,secondary))
            engine.return_value.search.assert_called_once_with(**payload.model_dump())
            self.assertEqual(result['data'],engine.return_value.search.return_value)
