import unittest
from adaptive_evidence.speaker_attribution import SpeakerAttribution,leading_label


def transcript(names=('Mira','Leon')):
    return [{'id':f'{n}-{i}','source_id':f'{n}-{i}','start':0,'role':'user',
             'content':f'{n}: We enjoy our shared hobby.'} for n in names for i in range(3)]


class SpeakerAttributionTests(unittest.TestCase):
    def test_different_speaker_cannot_supply_unattributed_preference(self):
        rows=transcript();guard=SpeakerAttribution(rows,'Which hobby does Mira enjoy?')
        self.assertTrue(guard.allows(rows[0]));self.assertFalse(guard.allows(rows[-1]))

    def test_other_speaker_can_explicitly_report_target(self):
        rows=transcript();guard=SpeakerAttribution(rows,'Which hobby does Mira enjoy?')
        self.assertTrue(guard.allows({**rows[-1],'content':'Leon: Mira enjoys painting.'}))

    def test_question_by_other_speaker_is_not_a_target_statement(self):
        rows=transcript();guard=SpeakerAttribution(rows,'Which hobby does Mira enjoy?')
        self.assertFalse(guard.allows({**rows[-1],'content':'Leon: What hobby do you enjoy?'}))

    def test_comparison_retains_both_requested_speakers(self):
        rows=transcript();guard=SpeakerAttribution(rows,'Compare Mira and Leon.')
        self.assertTrue(all(guard.allows(r) for r in rows))

    def test_query_without_known_author_is_unchanged(self):
        rows=transcript();guard=SpeakerAttribution(rows,'What hobby do I enjoy?')
        self.assertTrue(all(guard.allows(r) for r in rows))

    def test_unknown_source_remains_unchanged(self):
        rows=transcript();guard=SpeakerAttribution(rows,'What does Mira like?')
        self.assertTrue(guard.allows({'source_id':'unlabelled','content':'My hobby is painting.'}))

    def test_mixed_format_disables_attribution(self):
        rows=transcript()+[{'source_id':str(i),'start':0,'role':'user','content':'Unlabelled prose'} for i in range(4)]
        guard=SpeakerAttribution(rows,'What does Mira like?')
        self.assertFalse(guard.requested);self.assertTrue(all(guard.allows(r) for r in rows))

    def test_no_attribution_from_one_off_heading(self):
        rows=transcript();rows[-1]['content']='Summary: A fact.'
        self.assertFalse(SpeakerAttribution(rows,'What does Summary say?').requested)

    def test_source_owner_applies_to_later_chunks(self):
        rows=transcript();later={**rows[-1],'id':'later','start':300,'content':'We prefer puzzle games.'}
        guard=SpeakerAttribution(rows+[later],'What does Mira prefer?')
        self.assertFalse(guard.allows(later))

    def test_possessive_case_and_name_boundaries(self):
        rows=transcript();guard=SpeakerAttribution(rows,"What is MIRA's favorite hobby?")
        self.assertEqual(guard.requested,{'Mira'})
        self.assertFalse(SpeakerAttribution(rows,'What does Mirabelle prefer?').requested)

    def test_longer_known_label_wins_over_substring_label(self):
        rows=transcript(('Mary','Mary Jane'));guard=SpeakerAttribution(rows,'What does Mary Jane prefer?')
        self.assertEqual(guard.requested,{'Mary Jane'});self.assertFalse(guard.allows(rows[0]))

    def test_numbers_urls_and_code_are_not_speaker_labels(self):
        for text in ('2025: test','https://example.com','x: code','When was it?: question','Mira:no separating whitespace'):
            self.assertIsNone(leading_label(text))
        self.assertEqual(leading_label("Jean-Luc: A fact."),'Jean-Luc')

    def test_opaque_header_does_not_change_author_or_original_content(self):
        text='[2025-04-19 20:17] [chat] Mira: We enjoy painting.'
        self.assertEqual(leading_label(text),'Mira')
        self.assertEqual(text,'[2025-04-19 20:17] [chat] Mira: We enjoy painting.')

    def test_labels_across_both_roles_support_attribution(self):
        rows=transcript()
        for row in rows:
            if row['source_id'].startswith('Mira'):row['role']='assistant'
            row['content']='[opaque header] '+row['content']
        guard=SpeakerAttribution(rows,'What does Mira prefer?')
        self.assertEqual(guard.requested,{'Mira'});self.assertFalse(guard.allows(rows[-1]))
