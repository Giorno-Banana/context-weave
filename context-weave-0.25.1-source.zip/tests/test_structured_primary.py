import json
import unittest
import httpx
import test_bounded_selection as protocol_fixtures
from adaptive_evidence.local_planner import LocalEvidencePlanner,LocalPlanningError,parse_envelope
from adaptive_evidence.user_evidence import UserStatementPlanner


class StructuredPrimaryTests(unittest.TestCase):
    planner=protocol_fixtures.SupplementProtocolTests.planner

    def test_missing_outer_brace_recovered_without_changing_values(self):
        self.assertEqual(parse_envelope('{"queries":["a search"]',repair=True),{'queries':['a search']})
        self.assertEqual(parse_envelope('{"ids":[1,3]',repair=True),{'ids':[1,3]})
        with self.assertRaises(ValueError):parse_envelope('{"ids":[1,3]',repair=False)

    def test_partial_array_strings_extra_text_remain_failures(self):
        for raw in ('{"ids":[1,','{"queries":["unfinished]','{"ids":[1],','text {"ids":[1]','{"ids":[1] extra', '[1,2] garbage'):
            with self.assertRaises(ValueError):parse_envelope(raw,repair=True)

    def test_entire_primary_id_list_checked_before_sixteen_cap(self):
        data={'memories':[{'id':i} for i in range(1,34)]}
        for tail in (999,True,'17'):
            p=self.planner(LocalEvidencePlanner,list(range(1,17))+[tail])
            with self.assertRaises(LocalPlanningError):p.request('ids',data)

    def test_primary_batch_ids_are_contiguous_and_mapped_back(self):
        p=self.planner(LocalEvidencePlanner,[]);sizes=[]
        def request(field,data):
            ids=[r['id'] for r in data['memories']]
            self.assertEqual(ids,list(range(1,len(ids)+1)))
            sizes.append(len(ids));return [len(ids)]
        p.request=request
        result=p.select('Find sources',None,[{'content':'original source words '*250} for _ in range(9)])
        self.assertGreater(len(sizes),1)
        cumulative=[];total=0
        for size in sizes:total+=size;cumulative.append(total)
        self.assertEqual(result,cumulative)

    def test_invalid_second_batch_fails(self):
        p=self.planner(LocalEvidencePlanner,[]);calls=[]
        def request(field,data):
            calls.append(data);return [1] if len(calls)==1 else [len(data['memories'])+1]
        p.request=request
        with self.assertRaises(LocalPlanningError):p.select('Find sources',None,[{'content':'original source words '*250} for _ in range(9)])

    def test_secondary_retains_original_global_ids(self):
        p=self.planner(UserStatementPlanner,[]);seen=[]
        def request(field,data):seen.extend(r['id'] for r in data['memories']);return []
        p.request=request
        p.select('Find sources',None,[{'content':'original source words '*250} for _ in range(9)])
        self.assertEqual(seen,list(range(1,10)))

    def test_schema_and_completion_checked_after_repair(self):
        for raw,finish in [('{"ids":[1],"extra":[]','stop'),('{"queries":["a","b","c","d"]','stop'),('{"ids":[1]','length')]:
            p=self.planner(LocalEvidencePlanner,[])
            p.client.close()
            p.client=httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(200,json={'model':p.model,'choices':[{'finish_reason':finish,'message':{'content':raw}}]})))
            with self.assertRaises(LocalPlanningError):p.request('queries' if 'queries' in raw else 'ids',{'memories':[{'id':1}]})
