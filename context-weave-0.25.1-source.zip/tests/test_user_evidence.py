import unittest
from unittest.mock import patch
import test_contract as fixtures
from adaptive_evidence.local_planner import EvidenceSearch,LocalPlanningError
from adaptive_evidence.user_evidence import UserEvidenceSearch


class EmptyPlanner:
    def expand(self,*args):return []
    def select(self,*args):return []


class UserEvidenceTests(unittest.TestCase):
    setUp=fixtures.ContractTests.setUp
    tearDown=fixtures.ContractTests.tearDown
    add=fixtures.ContractTests.add

    def test_missing_statement_added_as_exact_source_and_scope_enforced(self):
        self.add(content='Project records include authentication.')
        self.add(request='rule',content='Always include library version numbers.')
        self.add(user='other',request='private',content='Private hidden user request.')
        pool=self.store.candidate_hits(user_id='u',query='library')
        rule=next(h for h in pool if 'version numbers' in h['content'])
        base=next(h for h in pool if 'authentication' in h['content'])
        captured=[]
        class Secondary:
            def select(self,q,options,candidates):
                captured.extend(candidates)
                return [next(i for i,h in enumerate(candidates,1) if h['id']==rule['id'])]
        search=UserEvidenceSearch(self.store,EmptyPlanner(),Secondary())
        with patch.object(search,'_search_chunks',return_value=[base]):
            result=search.search(user_id='u',query='library')
        self.assertEqual([h['content'] for h in result],[base['content'],rule['content']])
        self.assertNotIn('Private',str(captured)+str(result))

    def test_selected_existing_statement_keeps_exact_primary(self):
        self.add(content='Luna likes climbing.')
        class Secondary:
            def select(self,*args):return [1]
        args=dict(user_id='u',query='Luna',top_k=1)
        before=EvidenceSearch(self.store,EmptyPlanner()).search(**args)
        self.assertEqual(UserEvidenceSearch(self.store,EmptyPlanner(),Secondary()).search(**args),before)

    def test_failure_unknown_or_boolean_id_retains_primary(self):
        self.add(content='Luna likes climbing.')
        args=dict(user_id='u',query='Luna',top_k=1)
        before=EvidenceSearch(self.store,EmptyPlanner()).search(**args)
        for value in ([999],[True],None,LocalPlanningError('unavailable')):
            class Secondary:
                def select(self,*args):
                    if isinstance(value,Exception):raise value
                    return value
            self.assertEqual(UserEvidenceSearch(self.store,EmptyPlanner(),Secondary()).search(**args),before)

    def test_assistant_sources_never_sent_to_secondary(self):
        self.store.add(user_id='u',session_id='s',request_id='a',messages=[{'role':'assistant','content':'A proposed hypothetical example.'}])
        class Secondary:
            def select(self,*args):raise AssertionError('No actual user sources')
        self.assertTrue(UserEvidenceSearch(self.store,EmptyPlanner(),Secondary()).search(user_id='u',query='example'))

    def test_topk_and_supplement_budget(self):
        for n in range(12):self.add(request=str(n),content=f'Record {n} '+('Original source statement. '*30))
        pool=self.store.candidate_hits(user_id='u',query='record')
        class Secondary:
            def select(self,q,options,candidates):return list(range(1,len(candidates)+1))
        search=UserEvidenceSearch(self.store,EmptyPlanner(),Secondary())
        with patch.object(search,'_search_chunks',return_value=[pool[-1]]):
            result=search.search(user_id='u',query='record',top_k=100)
        extras=[h for h in result if h['id']!=pool[-1]['id']]
        self.assertLessEqual(len(extras),6)
        self.assertLessEqual(sum(len(h['content']) for h in extras),4000)
        with patch.object(search,'_search_chunks',return_value=[pool[-1]]):
            self.assertEqual(len(search.search(user_id='u',query='record',top_k=1)),1)

    def test_empty_scope_calls_no_planners(self):
        self.assertEqual(UserEvidenceSearch(self.store,None,None).search(user_id='empty',query='anything'),[])
