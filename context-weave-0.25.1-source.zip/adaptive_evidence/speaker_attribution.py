"""Conservative attribution for consistently speaker-labelled source transcripts.

This guard only constrains supplemental excerpts; it never rewrites a source or
filters existing primary evidence. Unlabelled or mixed-format text is unchanged.
"""
import re
from collections import Counter


def leading_label(text):
    first=text.split('\n',1)[0]
    # Opaque bracketed headers may precede a speaker label. Do not parse dates
    # or derive any facts from them; original source text remains untouched.
    first=re.sub(r'^\s*(?:\[[^\]\n]{1,128}\]\s*){1,3}', '', first)
    prefix,separator,body=first.partition(':')
    label=prefix.strip()
    if not separator or not body[:1].isspace() or not body.strip() or not 1<=len(label)<=64:
        return None
    words=label.split()
    if not 1<=len(words)<=4 or not all(w[0].isupper() for w in words):
        return None
    if not all(ch.isalpha() or ch in " .'-" for ch in label):
        return None
    return label


def mentions(text,label):
    return re.search(r'(?<!\w)'+re.escape(label)+r'(?!\w)',text,re.IGNORECASE) is not None


class SpeakerAttribution:
    def __init__(self,rows,query):
        starts={r['source_id']:r for r in rows if r['start']==0 and r['role'] in {'user','assistant'}}
        self.owners={sid:leading_label(r['content']) for sid,r in starts.items()}
        counts=Counter(label for label in self.owners.values() if label)
        recurring={label for label,count in counts.items() if count>=2}
        labelled=sum(label is not None for label in self.owners.values())
        enabled=bool(starts) and labelled/len(starts)>=.8 and len(recurring)>=2
        self.requested=set()
        if enabled:
            labels={label.casefold():label for label in recurring}
            pattern=r'(?<!\w)(?:'+'|'.join(re.escape(label) for label in sorted(recurring,key=len,reverse=True))+r')(?!\w)'
            self.requested={labels[m.group().casefold()] for m in re.finditer(pattern,query,re.IGNORECASE)}

    def allows(self,row):
        if not self.requested:
            return True
        owner=self.owners.get(row['source_id'])
        if owner is None or owner in self.requested:
            return True
        return any(mentions(row['content'],label) for label in self.requested)
