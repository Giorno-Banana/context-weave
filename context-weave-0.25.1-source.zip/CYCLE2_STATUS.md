# Active0.25.1 profile

Read README.md and EXPERIMENT.json. API18099, model18095; fresh scoped database. Same original-source retrieval algorithm as validated0.25.0, with both primary and supplemental planners wired through the API. Official score pending. No Full or new OpenRouter calls.
