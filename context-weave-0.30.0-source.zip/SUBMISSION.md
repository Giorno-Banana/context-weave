# Context Weave / SourceTrail 0.30.0

Textual, Answer-only generation. Add/Search generative calls: 0. Embedding remains text-embedding-v4, 1024 dimensions, batch 10. API/profile mode: document_focus; evidence budget: 24,000 characters. Add/Search concurrency: 16/16.

This release conditionally prioritizes original-user lexical evidence in scopes dominated by one long document. Other scopes preserve 0.29 ranking. Authentication, atomic writes, request-id idempotency, user scope, immediate retrieval, and persistent storage remain. Public diagnostics did not meet the declared strict improvement gate; the official Smoke is exploratory. No score is claimed before a completed run.

Original author: 王子铭 (Giorno-Banana), MIT. No upstream implementation or prompt was copied. See PROVENANCE.md for method inspiration and excluded LLM components.