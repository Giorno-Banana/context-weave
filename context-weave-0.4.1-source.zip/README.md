# Context Weave 0.4.1

Text memory service with a supervised local Qwen3.5-4B runtime. This candidate fixes GPU cleanup on the actual single-request Add path and bounds work that can continue after a client timeout. It preserves model weights, BF16, greedy decoding, thinking disabled, the source-span prompt, retrieval logic and embedding model from 0.4.0.

Submission contact: 秦天朗. Team: recursive roll. Repository: [Giorno-Banana/context-weave](https://github.com/Giorno-Banana/context-weave). Copyright: 王子铭; MIT license retained.

## Changes

Both single and batch generation use one GPU lifecycle. Inputs move to the GPU only when the worker owns the generation slot. Outputs move to CPU before decoding; temporary tensors and unused allocator blocks are released after every request, including errors. Metrics distinguish allocated/reserved memory, peak memory, generation and queue time. Logs contain counts/timings, never source text or answers.

A lightweight HTTP process supervises one spawned model worker. Queued requests stay on CPU and are bounded to 16. Disconnects cancel work. Generation has a 90-second budget and 5-second cancellation grace; a worker that cannot stop is terminated before a replacement starts. The total request budget is 150 seconds, below the Add client's 180-second timeout. Restart attempts are bounded to three per five minutes. No partial cancelled response is accepted as a successful index.

## Method and model disclosure

Add retains original text, role, session and timestamp. Chunks are at most 1,000 characters with 120-character overlap. The explicitly selected LLM chooses IDs of exact original spans. Validated spans reinforce embedding/BM25 indexing; generated text never becomes evidence. The local profile is Qwen3.5-4B, batch size two, with Search planning disabled. Bailian text-embedding-v4 supplies 1,024-dimensional document/query vectors. Search returns original passages using dense/BM25 fusion and adjacent windows, within a 24,000-character budget. Answer and Eval remain the platform's responsibility.

The OpenRouter GPT-4o-mini profile remains available and explicit. There is no automatic cloud fallback. Profiles and runtime revisions require separate databases.

## Validation and results

The frozen 0.4.0 official textual Smoke succeeded on 2026-10-08: **59.47, 46/46 items, 2h47m08s**, including one manual model restart and two recovered Add 503 responses. This is the baseline's result, not a score for 0.4.1. Historical 0.3.1 Smoke scored 53.64 on 46 items. No Full was started by this change.

0.4.1 has process-fault tests, HTTP contract tests and synthetic real-model validation. See [local_runtime/VALIDATION.md](local_runtime/VALIDATION.md) for the measured scope and limitations. It has not been submitted as an official evaluation.

## Run

Install the service's requirements.txt and the pinned model runtime dependencies. See [local_runtime/README.md](local_runtime/README.md) for the supervised launcher and timeout settings, [OPERATIONS.md](OPERATIONS.md) for authenticated Add/Search, and [MODEL_PROFILES.md](MODEL_PROFILES.md) for model/profile separation. Regression tests: `python -m unittest discover -s tests -v`.

The published competition FAQ requires gpt-4o-mini for academic LLM components. The submitter reports an organizer exception for local-model testing; this code does not certify eligibility. Disclose the actual model and frozen configuration.

The source bundle excludes credentials, private memories, model weights and third-party binaries. Model files retain their upstream licenses. See [PROVENANCE.md](PROVENANCE.md), [SUBMISSION.md](SUBMISSION.md) and [LICENSE](LICENSE).
