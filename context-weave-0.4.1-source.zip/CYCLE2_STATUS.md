# Candidate status

0.4.1 improves local generation cleanup, cancellation, process isolation and recovery. It preserves the Qwen weights and memory indexing method. Local validation is recorded in local_runtime/VALIDATION.md. No official 0.4.1 Smoke or Full has been started by this work.

Baseline 0.4.0: official textual Smoke succeeded on 2026-10-08, score 59.47, 46/46 items, duration 10028 seconds. The run required one manual model restart; two Add 503 errors recovered via platform retries and idempotent batch checkpoints. That observation motivated the new runtime. It does not establish the exact cause of the original slowdown or guarantee the next Full.
