param(
    [int]$Port = 18082,
    [string[]]$EnvFile,
    [string]$PythonPath,
    [ValidateSet('dashscope','bge')][string]$EmbeddingBackend = 'dashscope',
    [ValidateSet('cpu','cuda')][string]$Device = 'cpu',
    [ValidateSet('hybrid_window','hybrid','adaptive','dense')][string]$Mode = 'hybrid_window',
    [int]$ContextChars = 24000
)
$ErrorActionPreference = 'Stop'
foreach ($configPath in $EnvFile) {
    foreach ($line in Get-Content -LiteralPath $configPath -Encoding UTF8) {
        if ($line -match '^\s*(#|$)') { continue }
        if ($line -notmatch '^\s*([A-Za-z_][A-Za-z0-9_]*)=(.*)$') { throw 'Invalid environment file line.' }
        $settingName = $Matches[1]
        $settingValue = $Matches[2].Trim()
        if (($settingValue.StartsWith('"') -and $settingValue.EndsWith('"')) -or ($settingValue.StartsWith("'") -and $settingValue.EndsWith("'"))) {
            $settingValue = $settingValue.Substring(1, $settingValue.Length - 2)
        }
        [Environment]::SetEnvironmentVariable($settingName, $settingValue, 'Process')
    }
}
$projectPath = Split-Path -Parent $PSScriptRoot
if (-not $PythonPath) {
    $PythonPath = Join-Path $PSScriptRoot '.venv-cycle2\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $PythonPath)) { $PythonPath = 'python' }
}
$env:AE_EMBEDDING_BACKEND = $EmbeddingBackend
if ($EmbeddingBackend -eq 'bge') {
    $env:AE_EMBEDDING_PATH = Join-Path $projectPath 'MemoryBench-Shared\models\embeddings\bge-small-en-v1.5'
} elseif (-not $env:DASHSCOPE_API_KEY -or -not $env:AE_EMBEDDING_URL) {
    throw 'Set DASHSCOPE_API_KEY and AE_EMBEDDING_URL before starting the Cycle 2 service.'
}
if (-not $env:AE_DATABASE) { throw 'Set an explicit, separate AE_DATABASE for this model profile.' }
if (-not [IO.Path]::IsPathRooted($env:AE_DATABASE)) { $env:AE_DATABASE = Join-Path $PSScriptRoot $env:AE_DATABASE }
$env:AE_DATABASE = [IO.Path]::GetFullPath($env:AE_DATABASE)
$env:AE_ADD_INDEXER = '1'
if (-not $env:AE_ADD_LLM_BACKEND) { $env:AE_ADD_LLM_BACKEND = 'openrouter' }
if ($env:AE_ADD_LLM_BACKEND -eq 'openrouter' -and -not $env:OPENROUTER_API_KEY) {
    throw 'Set OPENROUTER_API_KEY for the OpenRouter profile.'
}
if ($env:AE_ADD_LLM_BACKEND -eq 'local') {
    if (-not $env:AE_LOCAL_LLM_MODEL -or -not $env:AE_LOCAL_LLM_REVISION) { throw 'Set the actual local model and revision.' }
    Remove-Item Env:\OPENROUTER_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:\OPENAI_API_KEY -ErrorAction SilentlyContinue
    if ($env:AE_PLANNER -eq '1') { throw 'The local-only profile requires AE_PLANNER=0.' }
}
$env:AE_DEVICE = $Device
$env:AE_MODE = $Mode
$env:AE_CONTEXT_CHARS = [string]$ContextChars
$env:PYTHONPATH = $PSScriptRoot
if (-not $env:MEMORY_API_KEY) { throw 'Set MEMORY_API_KEY before starting the service.' }
& $pythonPath -m uvicorn adaptive_evidence.api:app --host 127.0.0.1 --port $Port --workers 1 --no-access-log
exit $LASTEXITCODE
