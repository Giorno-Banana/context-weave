# 0.4.1 submission preparation

Local runtime improvement candidate. No official 0.4.1 evaluation has been started or bound by this change. Public version 0.4.0 has the historical 59.47 Smoke result and its original source remains frozen.

| Field | Value |
| --- | --- |
| Repository | Giorno-Banana/context-weave |
| Contact / team | 秦天朗 / recursive roll |
| Code copyright / license | 王子铭 / MIT |
| Add LLM | Qwen3.5-4B, local, BF16, thinking disabled |
| Embedding | Bailian text-embedding-v4, 1024 dimensions |
| Search planner | Disabled |
| Runtime revision | sha256-82566a6da25518d98b91c78ce9a7c5a3d09aee59dd25db5b123f65811ed8acfe |
| Local Add/Search | 127.0.0.1:18084 |
| Local model endpoint | 127.0.0.1:18091 |
| Official 0.4.1 score / Full | Not run |

Publish/freeze the candidate source and correct actual model information before any official evaluation. Never copy the baseline's score into this version. This document contains no evaluator key or API authentication token.
