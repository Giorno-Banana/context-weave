# 运行与复现：Context Weave 0.4.1

先按 local_runtime/README.md 启动监督式 Qwen 服务，等待 `http://127.0.0.1:18091/health` 中 loaded=true。模型权重和依赖需另外准备。启动模型进程不需要百炼或 OpenRouter 密钥。

Add/Search 使用 Python 3.10+ 和 requirements.txt。基础凭证写入私有 `.env`，再叠加 `local_runtime/profile.txt`。后者包含本版本的 Qwen revision、batch=2、concurrency=1、LLM timeout=180 和独立数据库。百炼维持 text-embedding-v4，Search planner 关闭。

```powershell
.\start_local.ps1 -Port 18084 -PythonPath C:\service-venv\Scripts\python.exe -EnvFile @('.env', 'local_runtime/profile.txt')
python preflight.py --env-file .env --env-file local_runtime/profile.txt
python preflight.py --env-file .env --env-file local_runtime/profile.txt --live --output runs/live-probe.json
```

离线 preflight 不调用模型；live 模式使用合成数据和临时数据库，会调用本地模型及百炼。持续模型压力测试不调用百炼。均不创建赛事任务。不要在官方任务进行中切换模型、提示词、版本或配置。

0.4.0 的 59.47 分属于冻结的旧版本。0.4.1 使用新源代码和新数据库，目前没有官方成绩；不要把新运行时挂到旧 revision 下。保留旧源代码、启动器和数据库，可以按原配置恢复 0.4.0。此源码变更本身不修改 Tailscale 公网路由、不创建 Full、不设置自启动。

排查时先看模型 health 的 active/queue_depth/counters/last_metrics，再看 Add/Search 的脱敏日志。allocated_mib 是仍存活张量；reserved_mib 是 PyTorch 缓存池。nvidia-smi 还包括驱动和其他图形进程，不能直接当作模型泄漏量。请求结束后临时张量释放，再调用 empty_cache；仍被活跃引用的张量无法靠 empty_cache 释放。
