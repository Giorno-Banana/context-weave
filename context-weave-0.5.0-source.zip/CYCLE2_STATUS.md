# Status — 0.5.0

Candidate prepared for official Smoke. No Full started; no 90+ score claimed. See README and the frozen validation report.
