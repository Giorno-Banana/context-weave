import unittest
from concurrent.futures import ThreadPoolExecutor

import test_contract as fixtures
from adaptive_evidence.core import Config, MemoryStore
from adaptive_evidence.evidence import pack_evidence, overview_order


class EvidenceTests(unittest.TestCase):
    setUp = fixtures.ContractTests.setUp
    tearDown = fixtures.ContractTests.tearDown
    add = fixtures.ContractTests.add

    def test_context_survives_character_budget(self):
        self.store = MemoryStore(self.path, self.encoder, Config(context_chars=330))
        self.store.add(user_id="u", request_id="r", session_id="s", messages=[
            {"role": "user", "content": "Mira purchased a cello from the conservatory."},
            {"role": "assistant", "content": "That happened on Tuesday afternoon."},
        ])
        for i in range(12):
            self.add(request=str(i), content="Mira practiced the cello in the conservatory music room.")
        index = self.store.index("u")
        anchor = next(i for i, row in enumerate(index.rows) if "purchased" in row["content"])
        order = [anchor] + [i for i in range(len(index.rows)) if i != anchor and "Tuesday" not in index.rows[i]["content"]]
        selected = pack_evidence(self.store, index, order, 100)
        self.assertTrue(any("Tuesday" in index.rows[i]["content"] for i in selected))
        self.assertLessEqual(sum(len(self.store.render(index.rows[i])) for i in selected), 330)

    def test_top_one_is_direct_and_no_unaffordable_text(self):
        self.add(content="A unique instrument was purchased.")
        hits = self.store.search(user_id="u", query="instrument", mode="evidence", top_k=1)
        self.assertEqual(1, len(hits))
        self.assertIn("unique instrument", hits[0]["content"])

    def test_scope_updates_and_concurrent_views(self):
        self.add(user="u", content="I own a silver bicycle.")
        self.add(user="other", content="I own a secret orange yacht.")
        with ThreadPoolExecutor(8) as pool:
            outputs = list(pool.map(lambda _: self.store.search(user_id="u", query="bicycles owned", mode="evidence"), range(16)))
        self.assertTrue(all("silver" in str(hits) and "yacht" not in str(hits) for hits in outputs))
        self.add(user="u", request="r2", content="I sold that bicycle and now own a green scooter.")
        self.assertIn("green scooter", str(self.store.search(user_id="u", query="What do I own now?", mode="evidence")))

    def test_identical_statements_at_distinct_dates_survive(self):
        for n in range(2):
            self.add(request=str(n), content="I visited the observatory.", timestamp=1700000000000+n*86400000)
        hits = self.store.search(user_id="u", query="List visits to the observatory", mode="evidence")
        self.assertEqual(2, len(hits))
        self.assertNotEqual(hits[0]["created_at"], hits[1]["created_at"])

    def test_overview_covers_sessions_but_fact_query_is_unchanged(self):
        for n in range(12):
            self.store.add(user_id="u", session_id="one" if n < 9 else f"session{n}", request_id=str(n),
                           messages=[{"role": "user", "content": f"Progress log entry {n}."}])
        index = self.store.index("u")
        ranked = list(range(len(index.rows)))
        self.assertEqual(ranked, overview_order(index, ranked, "Which entry mentioned the deadline?"))
        broad = overview_order(index, ranked, "Summarize the progress over time")
        self.assertEqual(set(ranked), set(broad))
        self.assertGreater(len({index.rows[i]['session_id'] for i in broad[:9]}), 1)
