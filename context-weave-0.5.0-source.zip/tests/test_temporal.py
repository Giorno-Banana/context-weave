import unittest
from datetime import datetime, timezone
from adaptive_evidence.temporal import calendar_note


class TemporalTests(unittest.TestCase):
    def stamp(self, value):
        return int(datetime.fromisoformat(value).replace(tzinfo=timezone.utc).timestamp()*1000)

    def test_year_boundary_and_calendar_granularity(self):
        note = calendar_note("Yesterday and last month I was away.", self.stamp("2024-01-01"))
        self.assertIn("2023-12-31", note)
        self.assertIn("2023-12 (month only)", note)
        self.assertNotIn("2023-12-01", note)

    def test_leap_day(self):
        self.assertIn("2024-02-29", calendar_note("Yesterday", self.stamp("2024-03-01")))

    def test_never_uses_wall_clock_or_event_dates_as_anchor(self):
        self.assertEqual("", calendar_note("In 2023 I said yesterday was great.", None))
        self.assertEqual("", calendar_note("[2023-99-99] Yesterday", None))
        self.assertIn("2023-03-31", calendar_note("[2023-04-01] Yesterday", None))
        self.assertIn("2023-03-31", calendar_note("[8:40 am on 1 April, 2023] Yesterday", None))

    def test_missing_or_nonrelative_text(self):
        self.assertEqual("", calendar_note("A fact dated 2024-01-01.", self.stamp("2024-01-01")))
