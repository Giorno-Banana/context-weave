import unittest
import httpx

from adaptive_evidence.reranker import LocalReranker, RerankerError, fuse_reranking


class RerankerTests(unittest.TestCase):
    def make(self, body=None, status=200):
        def handler(request):
            if request.url.path == "/health":
                return httpx.Response(200, json={"identity": "fixed"})
            return httpx.Response(status, json=body)
        return LocalReranker(transport=httpx.MockTransport(handler))

    def test_loopback_only(self):
        for url in ("https://external.example", "http://localhost@external.example", "http://localhost?token=x"):
            with self.assertRaises(ValueError):
                LocalReranker(url)

    def test_result_validation_and_safe_error(self):
        for body in ({"identity": "changed", "scores": [1.]},
                     {"identity": "fixed", "scores": []},
                     {"identity": "fixed", "scores": [True]},
                     {"identity": "fixed", "scores": ["wrong"]}):
            with self.assertRaises(RerankerError):
                self.make(body).score("a private query", ["private source"])
        with self.assertRaises(RerankerError) as raised:
            self.make({"error": "private source"}, 503).score("private query", ["source"])
        self.assertNotIn("private", str(raised.exception))

    def test_fusion_is_permutation_and_retains_tail(self):
        order = fuse_reranking(None, [8, 3, 4, 2, 1], [-8, 9, 0])
        self.assertEqual(order[0], 3)
        self.assertEqual(order[-2:], [2, 1])
        self.assertEqual(sorted(order), [1, 2, 3, 4, 8])
