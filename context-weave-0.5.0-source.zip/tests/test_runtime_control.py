"""Real spawned-process failure tests, with no model or GPU dependency."""
import asyncio
import os
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'local_runtime/competition'))
from runtime_control import Limits, RuntimeFailure, Supervisor
from inference_runtime import completion_length


def fake_worker(pipe, cancelled):
    pipe.send({'type': 'ready'})
    while True:
        message = pipe.recv()
        payload, number = message['payload'], message['number']
        action = payload.get('action', 'ok')
        if action == 'crash':
            os._exit(17)
        if action == 'hang':
            time.sleep(30)
        if action == 'error':
            pipe.send(dict(type='error', number=number, code='secret raw prompt'))
            continue
        end = time.monotonic() + payload.get('delay', 0)
        while time.monotonic() < end:
            if cancelled.is_set() or time.monotonic() >= message['deadline']:
                pipe.send(dict(type='error', number=number, code='generation_cancelled'))
                break
            time.sleep(.005)
        else:
            pipe.send(dict(type='result', number=number, result=dict(
                rows=[[str(os.getpid()), 10, 2] for _ in payload.get('requests', [None])],
                limit=20, metrics={})))


class SupervisorTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.control = Supervisor(fake_worker, Limits(generation=.45, grace=.15, request=1.5,
            startup=5, queue=2, restart_delay=.05, restart_count=20))
        await self.control.start()
        await self.wait_ready()

    async def asyncTearDown(self):
        await self.control.close()
        self.assertIsNone(self.control.process)

    async def wait_ready(self, different_pid=None):
        until = time.monotonic() + 6
        while time.monotonic() < until:
            health = self.control.health()
            if health['loaded'] and health['worker_pid'] != different_pid:
                return health['worker_pid']
            await asyncio.sleep(.01)
        self.fail(f'worker did not become ready: {self.control.health()}')

    async def wait_active(self):
        for _ in range(100):
            if self.control.active:
                return
            await asyncio.sleep(.01)
        self.fail('job did not start')

    async def test_normal_calls_share_worker_and_report_queue_time(self):
        a = asyncio.create_task(self.control.submit({'delay': .12}))
        await self.wait_active()
        b = asyncio.create_task(self.control.submit({}))
        first, second = await asyncio.gather(a, b)
        self.assertEqual(first['rows'], second['rows'])
        self.assertGreater(second['metrics']['queue_seconds'], .08)
        self.assertEqual(2, self.control.counts['completed'])

    async def test_hard_hang_is_killed_then_fresh_process_serves(self):
        pid = self.control.health()['worker_pid']
        start = time.monotonic()
        with self.assertRaisesRegex(RuntimeFailure, 'generation_deadline'):
            await self.control.submit({'action': 'hang'})
        self.assertLess(time.monotonic()-start, 2)
        new_pid = await self.wait_ready(pid)
        response = await self.control.submit({})
        self.assertEqual(str(new_pid), response['rows'][0][0])
        self.assertEqual(1, self.control.counts['hard_recycles'])

    async def test_cooperative_timeout_does_not_return_partial_success(self):
        pid = self.control.health()['worker_pid']
        with self.assertRaises(RuntimeFailure):
            await self.control.submit({'delay': 5})
        result = await self.control.submit({})
        self.assertEqual(str(pid), result['rows'][0][0])
        self.assertEqual(0, self.control.counts['hard_recycles'])

    async def test_queued_cancellation_never_cancels_active_request(self):
        active = asyncio.create_task(self.control.submit({'delay': .2}))
        await self.wait_active()
        queued = asyncio.create_task(self.control.submit({'action': 'hang'}))
        await asyncio.sleep(.025)
        queued.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await queued
        await active
        await self.control.submit({})
        self.assertEqual(2, self.control.counts['completed'])
        self.assertEqual(0, self.control.counts['hard_recycles'])

    async def test_active_task_cancellation_releases_gpu_before_next_job(self):
        active = asyncio.create_task(self.control.submit({'delay': 5}))
        await self.wait_active()
        active.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await active
        await self.control.submit({})
        self.assertEqual(1, self.control.counts['completed'])

    async def test_disconnect_is_cancelled_and_can_recover(self):
        start = time.monotonic()
        async def disconnected():
            return time.monotonic()-start > .1
        with self.assertRaisesRegex(RuntimeFailure, 'client_disconnected'):
            await self.control.submit({'delay': 5}, disconnected)
        await self.control.submit({})

    async def test_bounded_queue_rejects_overload(self):
        active = asyncio.create_task(self.control.submit({'delay': .25}))
        await self.wait_active()
        queued = [asyncio.create_task(self.control.submit({})) for _ in range(2)]
        await asyncio.sleep(.025)
        with self.assertRaises(RuntimeFailure) as caught:
            await self.control.submit({})
        self.assertEqual(429, caught.exception.status)
        await asyncio.gather(active, *queued)

    async def test_crash_recovers_and_error_content_is_sanitized(self):
        pid = self.control.health()['worker_pid']
        with self.assertRaisesRegex(RuntimeFailure, 'worker_exited'):
            await self.control.submit({'action': 'crash'})
        await self.wait_ready(pid)
        with self.assertRaisesRegex(RuntimeFailure, '^inference_failed$'):
            await self.control.submit({'action': 'error'})
        self.assertNotIn('secret', str(self.control.health()))
        await self.wait_ready()
        await self.control.submit({})

    async def test_idle_worker_death_recovers_without_a_request(self):
        pid = self.control.health()['worker_pid']
        self.control.process.terminate()
        new_pid = await self.wait_ready(pid)
        result = await self.control.submit({})
        self.assertEqual(str(new_pid), result['rows'][0][0])

    async def test_queue_wait_counts_toward_total_budget(self):
        self.control.limits = Limits(generation=.4, grace=.1, request=.55, startup=5, queue=2)
        active = asyncio.create_task(self.control.submit({'delay': .35}))
        await self.wait_active()
        start = time.monotonic()
        with self.assertRaises(RuntimeFailure):
            await self.control.submit({'delay': .3})
        self.assertLess(time.monotonic()-start, .8)
        await active

    async def test_shutdown_reaps_active_worker_and_rejects_new_work(self):
        active = asyncio.create_task(self.control.submit({'action': 'hang'}))
        await self.wait_active()
        await self.control.close()
        with self.assertRaises(RuntimeFailure):
            await active
        with self.assertRaises(RuntimeFailure):
            await self.control.submit({})


class TokenTests(unittest.TestCase):
    def test_eos_and_pad_accounting(self):
        self.assertEqual(3, completion_length([5, 6, 2, 0, 0], [2, 3]))
        self.assertEqual(2, completion_length([5, 3, 0], [2, 3]))
        self.assertEqual(3, completion_length([5, 6, 7], 2))


class HttpTests(unittest.TestCase):
    def test_single_and_batch_contract_and_model_identity(self):
        from fastapi.testclient import TestClient
        from supervised_server import create_app
        app = create_app(fake_worker, Limits(startup=10))
        with TestClient(app) as client:
            payload = dict(model='Qwen3.5-4B', messages=[dict(role='user', content='test')])
            single = client.post('/v1/chat/completions', json=payload)
            self.assertEqual(200, single.status_code)
            self.assertEqual('Qwen3.5-4B', single.json()['model'])
            self.assertEqual('stop', single.json()['choices'][0]['finish_reason'])
            self.assertEqual(12, single.json()['usage']['total_tokens'])
            batch = client.post('/v1/chat/completions/batch', json={'requests': [payload, payload]})
            self.assertEqual(200, batch.status_code)
            self.assertEqual(2, len(batch.json()['responses']))
            self.assertIn('queue_seconds', batch.json()['local_metrics'])
            self.assertEqual(400, client.post('/v1/chat/completions', json={**payload, 'model': 'other'}).status_code)
            self.assertEqual(422, client.post('/v1/chat/completions', json={**payload, 'max_tokens': 0}).status_code)
            self.assertEqual(400, client.post('/v1/chat/completions/batch', json={
                'requests': [payload, {**payload, 'max_tokens': 32}]}).status_code)
            self.assertEqual(2, client.get('/health').json()['counters']['completed'])


if __name__ == '__main__':
    unittest.main()
