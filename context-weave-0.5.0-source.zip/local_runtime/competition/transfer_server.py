"""Use safetensors positional reads to avoid Windows mmap access violations."""
import os

os.environ['HF_DEACTIVATE_ASYNC_LOAD'] = '1'

import transformers.modeling_utils as loading
import v4_server

original_safe_open = loading.safe_open


def positional_safe_open(*args, **kwargs):
    if kwargs.get('framework') == 'pt' and str(kwargs.get('device', 'cpu')) == 'cpu':
        kwargs['backend'] = 'pread'
    return original_safe_open(*args, **kwargs)


loading.safe_open = positional_safe_open


if __name__ == '__main__':
    print('Transfer runtime: safetensors pread CPU loading; unchanged weights, dtype and generation', flush=True)
    v4_server.server.main()
