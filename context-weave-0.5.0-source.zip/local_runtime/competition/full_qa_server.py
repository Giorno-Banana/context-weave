"""Local evaluation adapter, preserving per-sequence EOS accounting in batches."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "models"))
import openai_local_server as server


def completion_length(ids, eos_ids):
    """Include the first EOS, exclude padding appended after that sequence ends."""
    eos = {eos_ids} if isinstance(eos_ids, int) else set(eos_ids or [])
    return next((i + 1 for i, value in enumerate(ids) if value in eos), len(ids))


def generate_batch(requests):
    if not requests:
        return [], 0, 0.
    specifications = {(r.max_tokens, r.temperature, bool(r.response_format)) for r in requests}
    if len(specifications) != 1:
        raise server.HTTPException(400, "Batch settings must match")
    max_tokens, temperature, structured = specifications.pop()
    tokenizer, model = server.state["tokenizer"], server.state["model"]
    prompts = [server.render_chat(tokenizer, [m.model_dump() for m in r.messages]) for r in requests]
    limit = min(max_tokens, server.MAX_STRUCTURED_OUTPUT_TOKENS if structured else server.MAX_OUTPUT_TOKENS)
    with server.generation_lock, server.torch.inference_mode():
        # Variable prompt lengths otherwise accumulate cached CUDA blocks on
        # this Windows laptop, triggering slow shared-memory spillover.
        server.torch.cuda.empty_cache()
        server.torch.cuda.reset_peak_memory_stats()
        old_padding = tokenizer.padding_side
        tokenizer.padding_side = "left"
        try:
            encoded = tokenizer(prompts, return_tensors="pt", add_special_tokens=False, padding=True)
        finally:
            tokenizer.padding_side = old_padding
        lengths = encoded["attention_mask"].sum(dim=1).tolist()
        width = encoded["input_ids"].shape[-1]
        if width > server.MAX_INPUT_TOKENS:
            raise server.HTTPException(400, "Input exceeds configured token budget")
        encoded = {k: v.to(model.get_input_embeddings().weight.device) for k, v in encoded.items()}
        started = server.time.perf_counter()
        output = model.generate(**encoded, max_new_tokens=limit,
            do_sample=temperature > 0, temperature=temperature if temperature > 0 else None,
            pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id)
        server.torch.cuda.synchronize()
        elapsed = server.time.perf_counter() - started
        eos_ids = model.generation_config.eos_token_id
        values = output[:, width:].tolist()
        result = []
        for row, input_length in zip(values, lengths):
            length = completion_length(row, eos_ids)
            answer = server.clean_answer(tokenizer.decode(row[:length], skip_special_tokens=False))
            result.append((answer, int(input_length), length))
        print({"batch": len(requests), "input_tokens": lengths,
               "seconds": round(elapsed, 2),
               "peak_allocated_mib": round(server.torch.cuda.max_memory_allocated()/1024**2),
               "peak_reserved_mib": round(server.torch.cuda.max_memory_reserved()/1024**2)}, flush=True)
        del encoded, output
        server.torch.cuda.empty_cache()
        return result, limit, elapsed


server.generate_batch = generate_batch


if __name__ == "__main__":
    server.main()
