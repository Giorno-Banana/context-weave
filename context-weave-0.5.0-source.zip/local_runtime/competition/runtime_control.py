"""One GPU worker, bounded CPU queue, and deadlines enforced outside CUDA."""
from __future__ import annotations

import asyncio
import multiprocessing as mp
import time
from collections import deque
from dataclasses import dataclass


class RuntimeFailure(Exception):
    def __init__(self, status: int, code: str):
        super().__init__(code)
        self.status, self.code = status, code


@dataclass(frozen=True)
class Limits:
    generation: float = 90
    grace: float = 5
    request: float = 150
    startup: float = 90
    queue: int = 16
    restart_delay: float = 2
    restart_window: float = 300
    restart_count: int = 3

    def __post_init__(self):
        if min(self.generation, self.grace, self.request, self.startup,
               self.queue, self.restart_window, self.restart_count) <= 0:
            raise ValueError('Runtime limits must be positive')
        if self.request <= self.generation + self.grace:
            raise ValueError('Request budget must exceed generation plus cancellation grace')


@dataclass
class Job:
    payload: dict
    future: asyncio.Future
    enqueued: float
    deadline: float
    cancelled: bool = False


class Supervisor:
    def __init__(self, worker_target, limits=None):
        self.target = worker_target
        self.limits = limits or Limits()
        self.context = mp.get_context('spawn')
        self.queue = asyncio.Queue(maxsize=self.limits.queue)
        self.process = self.pipe = self.cancel_event = None
        self.runner = self.active = None
        self.ready = self.closed = False
        self.starts = deque()
        self.counts = dict(completed=0, failed=0, cancelled=0, hard_recycles=0, starts=0)
        self.last_metrics = {}
        self.last_error = None
        self.serial = 0

    def health(self):
        alive = bool(self.process and self.process.is_alive())
        return dict(status='busy' if self.active and alive else
                    'ready' if self.ready and alive else 'recovering',
                    loaded=self.ready and alive, worker_pid=self.process.pid if alive else None,
                    queue_depth=self.queue.qsize(), active=bool(self.active),
                    counters=dict(self.counts), last_error=self.last_error,
                    last_metrics=dict(self.last_metrics))

    async def start(self):
        # HTTP stays responsive during warmup/recovery. Startup failure is visible
        # in health, and pending requests retain their original total deadlines.
        self.runner = asyncio.create_task(self._run())
        self.runner.add_done_callback(self._runner_done)

    def _runner_done(self, task):
        if not task.cancelled() and task.exception() is not None:
            self.ready = False
            self.last_error = 'supervisor_stopped'
            while not self.queue.empty():
                job = self.queue.get_nowait()
                self._finish(job, error=RuntimeFailure(503, 'supervisor_stopped'))
                self.queue.task_done()

    async def close(self):
        self.closed = True
        if self.active:
            self._cancel(self.active)
        if self.runner:
            self.runner.cancel()
            try:
                await self.runner
            except asyncio.CancelledError:
                pass
        while not self.queue.empty():
            job = self.queue.get_nowait()
            self._finish(job, error=RuntimeFailure(503, 'runtime_stopped'))
            self.queue.task_done()
        await self._retire()

    async def submit(self, payload, disconnected=None):
        if self.closed or (self.runner and self.runner.done()):
            raise RuntimeFailure(503, 'runtime_stopped')
        now = time.monotonic()
        job = Job(payload, asyncio.get_running_loop().create_future(), now, now + self.limits.request)
        try:
            self.queue.put_nowait(job)
        except asyncio.QueueFull:
            raise RuntimeFailure(429, 'local_queue_full') from None
        try:
            while True:
                if job.future.done():
                    return job.future.result()
                if time.monotonic() >= job.deadline:
                    raise RuntimeFailure(504, 'request_deadline')
                if disconnected and await disconnected():
                    raise RuntimeFailure(499, 'client_disconnected')
                try:
                    return await asyncio.wait_for(asyncio.shield(job.future), .05)
                except asyncio.TimeoutError:
                    continue
        finally:
            if not job.future.done():
                self._cancel(job)
                job.future.cancel()

    def _cancel(self, job):
        if not job.cancelled:
            self.counts['cancelled'] += 1
        job.cancelled = True
        if job is self.active and self.cancel_event:
            self.cancel_event.set()

    @staticmethod
    def _finish(job, result=None, error=None):
        if not job.future.done():
            if error:
                # Do not share a traceback from this still-running supervisor
                # with request handlers (which may clear exception frames).
                job.future.set_exception(RuntimeFailure(error.status, error.code))
            else:
                job.future.set_result(result)

    async def _retire(self):
        self.ready = False
        process = self.process
        if process:
            if process.is_alive():
                process.terminate()
            until = time.monotonic() + 3
            while process.is_alive() and time.monotonic() < until:
                await asyncio.sleep(.025)
            if process.is_alive():
                process.kill()
                until = time.monotonic() + 3
                while process.is_alive() and time.monotonic() < until:
                    await asyncio.sleep(.025)
            if process.is_alive():
                # Never load a second model while the old GPU owner still lives.
                raise RuntimeFailure(503, 'worker_could_not_exit')
            process.join(timeout=0)
            process.close()
        if self.pipe:
            self.pipe.close()
        self.process = self.pipe = self.cancel_event = None

    def _receive(self):
        try:
            if self.pipe and self.pipe.poll():
                return self.pipe.recv()
        except (EOFError, OSError):
            raise RuntimeFailure(503, 'worker_exited') from None
        if not self.process or not self.process.is_alive():
            raise RuntimeFailure(503, 'worker_exited')
        return None

    async def _ensure_worker(self):
        if self.ready and self.process and self.process.is_alive():
            return
        await self._retire()
        now = time.monotonic()
        while self.starts and now - self.starts[0] >= self.limits.restart_window:
            self.starts.popleft()
        if len(self.starts) >= self.limits.restart_count:
            raise RuntimeFailure(503, 'restart_circuit_open')
        parent, child = self.context.Pipe()
        event = self.context.Event()
        process = self.context.Process(target=self.target, args=(child, event), daemon=True)
        try:
            process.start()
        except Exception:
            parent.close()
            child.close()
            raise RuntimeFailure(503, 'worker_start_failed') from None
        child.close()
        self.pipe, self.cancel_event, self.process = parent, event, process
        self.starts.append(now)
        self.counts['starts'] += 1
        while time.monotonic() - now < self.limits.startup:
            message = self._receive()
            if message is not None:
                if message.get('type') != 'ready':
                    raise RuntimeFailure(503, 'worker_load_failed')
                self.ready = True
                return
            await asyncio.sleep(.025)
        raise RuntimeFailure(503, 'worker_startup_deadline')

    async def _execute(self, job):
        self.cancel_event.clear()
        self.serial += 1
        number = self.serial
        now = time.monotonic()
        soft_end = min(now + self.limits.generation, job.deadline - self.limits.grace)
        if soft_end <= now:
            raise RuntimeFailure(504, 'request_deadline')
        self.pipe.send(dict(type='generate', number=number, payload=job.payload, deadline=soft_end))
        cancelled_at = None
        while True:
            now = time.monotonic()
            if job.cancelled or now >= soft_end:
                if cancelled_at is None:
                    cancelled_at = now
                    self.cancel_event.set()
                if now - cancelled_at >= self.limits.grace:
                    self.counts['hard_recycles'] += 1
                    await self._retire()
                    raise RuntimeFailure(504, 'generation_cancelled' if job.cancelled else 'generation_deadline')
            message = self._receive()
            if message is not None:
                if message.get('number') != number:
                    raise RuntimeFailure(503, 'worker_protocol_error')
                if cancelled_at is not None or job.cancelled:
                    raise RuntimeFailure(504, 'generation_cancelled' if job.cancelled else 'generation_deadline')
                if message.get('type') == 'error':
                    # Codes are chosen by our worker, never exception text.
                    allowed = {'invalid_request', 'generation_deadline', 'generation_cancelled', 'inference_failed'}
                    code = message.get('code')
                    if code not in allowed:
                        code = 'inference_failed'
                    if code == 'inference_failed':
                        await self._retire()
                    raise RuntimeFailure(400 if code == 'invalid_request' else 504 if code.startswith('generation_') else 503, code)
                if message.get('type') != 'result':
                    raise RuntimeFailure(503, 'worker_protocol_error')
                result = message['result']
                result.setdefault('metrics', {})
                return result
            await asyncio.sleep(.025)

    async def _run(self):
        while not self.closed:
            try:
                await self._ensure_worker()
            except RuntimeFailure as error:
                self.last_error = error.code
                await self._retire()
                # Fail queued callers promptly when loading cannot succeed.
                while not self.queue.empty():
                    job = self.queue.get_nowait()
                    self._finish(job, error=error)
                    self.queue.task_done()
                await asyncio.sleep(self.limits.restart_delay)
                continue
            try:
                job = await asyncio.wait_for(self.queue.get(), .25)
            except asyncio.TimeoutError:
                # Notice a crashed idle child even when no new request arrives.
                continue
            self.active = job
            dispatched = time.monotonic()
            try:
                if job.cancelled or job.future.cancelled():
                    continue
                if time.monotonic() >= job.deadline:
                    raise RuntimeFailure(504, 'request_deadline')
                result = await self._execute(job)
                result['metrics']['queue_seconds'] = round(dispatched - job.enqueued, 6)
                self.last_metrics = dict(result['metrics'])
                self.last_error = None
                self.counts['completed'] += 1
                self._finish(job, result=result)
            except (OSError, RuntimeFailure) as error:
                if not isinstance(error, RuntimeFailure):
                    error = RuntimeFailure(503, 'worker_exited')
                self.last_error = error.code
                self.counts['failed'] += 1
                self._finish(job, error=error)
                if error.status == 503:
                    await self._retire()
            finally:
                if self.closed:
                    self._finish(job, error=RuntimeFailure(503, 'runtime_stopped'))
                self.active = None
                self.queue.task_done()
