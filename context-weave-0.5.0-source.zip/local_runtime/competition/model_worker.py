"""Spawn entry point: only the child imports torch or owns CUDA allocations."""
import gc
import json
import multiprocessing as mp
import os
import threading
import traceback


def worker_main(pipe, cancelled):
    # Windows does not automatically reap a subprocess if its parent is killed.
    # This thread waits on the parent process handle, independently of generation.
    def parent_watch():
        from multiprocessing.connection import wait
        parent = mp.parent_process()
        if parent is not None:
            wait([parent.sentinel])
            os._exit(0)
    threading.Thread(target=parent_watch, daemon=True).start()
    try:
        import transfer_server
        from inference_runtime import GenerationInterrupted, generate
        server = transfer_server.v4_server.server
        server.load_model()
    except Exception:
        pipe.send({'type': 'load_error'})
        return
    pipe.send({'type': 'ready'})
    try:
        while True:
            message = pipe.recv()
            number = message['number']
            error = None
            result = None
            try:
                requests = [server.ChatRequest.model_validate(r) for r in message['payload']['requests']]
                result = generate(server, requests, cancelled, message['deadline'])
            except GenerationInterrupted as exc:
                error = 'generation_cancelled' if cancelled.is_set() else 'generation_deadline'
                traceback.clear_frames(exc.__traceback__)
            except server.HTTPException as exc:
                error = 'invalid_request'
                traceback.clear_frames(exc.__traceback__)
            except Exception as exc:
                # No prompts, credentials, generated text, or exception strings
                # in logs/health. A CUDA error poisons this worker, so retire it.
                error = 'inference_failed'
                traceback.clear_frames(exc.__traceback__)
            if error:
                gc.collect()
                server.torch.cuda.empty_cache()
                print(json.dumps(dict(event='generation_error', code=error, number=number)), flush=True)
                pipe.send(dict(type='error', number=number, code=error))
                if error == 'inference_failed':
                    return
            else:
                print(json.dumps(dict(event='generation', number=number, **result['metrics'])), flush=True)
                pipe.send(dict(type='result', number=number, result=result))
            # These are CPU-only, but do not retain the last request/answer.
            message = requests = result = None
    except (EOFError, BrokenPipeError, OSError):
        return
    finally:
        pipe.close()
