"""Shared single/batch GPU lifecycle; no request tensors survive a call."""
from __future__ import annotations

import gc
import time


class GenerationInterrupted(Exception):
    pass


def completion_length(ids, eos_ids):
    eos = {eos_ids} if isinstance(eos_ids, int) else set(eos_ids or [])
    return next((i + 1 for i, value in enumerate(ids) if value in eos), len(ids))


def generate(server, requests, cancelled, deadline):
    from transformers import StoppingCriteria, StoppingCriteriaList

    class Deadline(StoppingCriteria):
        def __call__(self, input_ids, scores, **kwargs):
            return cancelled.is_set() or time.monotonic() >= deadline

    specs = {(r.max_tokens, r.temperature, bool(r.response_format)) for r in requests}
    if len(specs) != 1:
        raise server.HTTPException(400, 'Batch settings must match')
    maximum, temperature, structured = specs.pop()
    limit = min(maximum, server.MAX_STRUCTURED_OUTPUT_TOKENS if structured else server.MAX_OUTPUT_TOKENS)
    tokenizer, model, torch = server.state['tokenizer'], server.state['model'], server.torch
    started = time.perf_counter()
    encoded = output = None
    result = None
    with server.generation_lock, torch.inference_mode():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        try:
            if cancelled.is_set() or time.monotonic() >= deadline:
                raise GenerationInterrupted()
            prompts = [server.render_chat(tokenizer, [m.model_dump() for m in r.messages]) for r in requests]
            padding = tokenizer.padding_side
            tokenizer.padding_side = 'left'
            try:
                encoded = tokenizer(prompts, return_tensors='pt', add_special_tokens=False, padding=True)
            finally:
                tokenizer.padding_side = padding
            lengths = encoded['attention_mask'].sum(dim=1).tolist()
            width = int(encoded['input_ids'].shape[-1])
            if width > server.MAX_INPUT_TOKENS:
                raise server.HTTPException(400, 'Input exceeds configured token budget')
            encoded = {k: v.to(model.get_input_embeddings().weight.device) for k, v in encoded.items()}
            output = model.generate(**encoded, max_new_tokens=limit,
                do_sample=temperature > 0, temperature=temperature if temperature > 0 else None,
                pad_token_id=tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id,
                stopping_criteria=StoppingCriteriaList([Deadline()]))
            torch.cuda.synchronize()
            if cancelled.is_set() or time.monotonic() >= deadline:
                # A partial response must never be mistaken for a successful index.
                raise GenerationInterrupted()
            values = output[:, width:].cpu().tolist()
            eos_ids = model.generation_config.eos_token_id
            rows = []
            for ids, input_length in zip(values, lengths, strict=True):
                length = completion_length(ids, eos_ids)
                answer = server.clean_answer(tokenizer.decode(ids[:length], skip_special_tokens=False))
                rows.append([answer, int(input_length), length])
            result = dict(rows=rows, limit=limit, metrics=dict(
                generation_seconds=round(time.perf_counter() - started, 6),
                batch_size=len(rows), prompt_tokens=sum(lengths),
                completion_tokens=sum(r[2] for r in rows),
                peak_allocated_mib=round(torch.cuda.max_memory_allocated()/1024**2, 2),
                peak_reserved_mib=round(torch.cuda.max_memory_reserved()/1024**2, 2)))
        finally:
            # Release views/base tensors before empty_cache. Exceptions get an
            # additional cleanup after their traceback is cleared in the worker.
            encoded = output = None
            gc.collect()
            torch.cuda.empty_cache()
        result['metrics'].update(
            allocated_mib=round(torch.cuda.memory_allocated()/1024**2, 2),
            reserved_mib=round(torch.cuda.memory_reserved()/1024**2, 2),
            lifecycle_seconds=round(time.perf_counter() - started, 6))
    return result
