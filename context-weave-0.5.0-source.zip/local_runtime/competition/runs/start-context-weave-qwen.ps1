param([int]$Port = 18090)
$ErrorActionPreference = 'Stop'
$competitionPath = Split-Path -Parent $PSScriptRoot
$workspacePath = Split-Path -Parent $competitionPath
Set-Location -LiteralPath $workspacePath
$env:PYTHONPATH = Join-Path $workspacePath 'models\qwen35_runtime'
$env:HF_DEACTIVATE_ASYNC_LOAD = '1'
$env:HF_HUB_OFFLINE = '1'
$env:TRANSFORMERS_OFFLINE = '1'
$env:LOCAL_MODEL_PATH = Join-Path $workspacePath 'models\Qwen3.5-4B'
$env:LOCAL_MODEL_NAME = 'Qwen3.5-4B'
$env:LOCAL_DEVICE = 'cuda:0'
$env:LOCAL_GPU_MEMORY = '9GiB'
$env:LOCAL_CPU_MEMORY = '18GiB'
$env:LOCAL_MAX_INPUT_TOKENS = '8192'
$env:LOCAL_MAX_OUTPUT_TOKENS = '1024'
$env:LOCAL_MAX_STRUCTURED_OUTPUT_TOKENS = '1024'
$env:LOCAL_DISABLE_THINKING = '1'
$env:LOCAL_SYSTEM_PROMPT = ''
$env:LOCAL_TRACE_JSONL = ''
Remove-Item Env:\OPENROUTER_API_KEY, Env:\OPENAI_API_KEY, Env:\DASHSCOPE_API_KEY, Env:\MEMORY_API_KEY -ErrorAction SilentlyContinue
$pythonPath = Join-Path $workspacePath 'models\.venv\Scripts\python.exe'
$serverPath = Join-Path $competitionPath 'transfer_server.py'
& $pythonPath -u $serverPath --host 127.0.0.1 --port $Port
exit $LASTEXITCODE
