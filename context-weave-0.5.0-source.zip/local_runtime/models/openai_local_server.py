"""Small OpenAI-compatible Transformers server for local benchmark runs.

Designed for one request at a time and GPU/CPU weight offload on a 12 GB GPU.
Configuration is supplied through LOCAL_* environment variables; see --help.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import threading
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

import torch
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from transformers import AutoModelForCausalLM, AutoTokenizer


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    model: str | None = None
    messages: list[Message]
    temperature: float = 0.0
    response_format: dict | None = None
    # The official memory-benchmarks OpenAI client requests 4096 output tokens
    # for both answer generation and structured judging. Accept that contract
    # even though the benchmark normally reaches EOS far earlier.
    max_tokens: int = Field(default=256, ge=1, le=4096)


class BatchChatRequest(BaseModel):
    requests: list[ChatRequest] = Field(min_length=1, max_length=8)


MODEL_PATH = Path(os.environ.get("LOCAL_MODEL_PATH", "models/Qwen3-8B")).resolve()
MODEL_NAME = os.environ.get("LOCAL_MODEL_NAME", MODEL_PATH.name)
DEVICE = os.environ.get("LOCAL_DEVICE", "cuda:0")
MAX_INPUT_TOKENS = int(os.environ.get("LOCAL_MAX_INPUT_TOKENS", "32768"))
MAX_OUTPUT_TOKENS = int(os.environ.get("LOCAL_MAX_OUTPUT_TOKENS", "4096"))
MAX_STRUCTURED_OUTPUT_TOKENS = int(
    os.environ.get("LOCAL_MAX_STRUCTURED_OUTPUT_TOKENS", str(MAX_OUTPUT_TOKENS))
)
GPU_MEMORY = os.environ.get("LOCAL_GPU_MEMORY", "8GiB")
CPU_MEMORY = os.environ.get("LOCAL_CPU_MEMORY", "18GiB")
DISABLE_THINKING = os.environ.get("LOCAL_DISABLE_THINKING", "1") != "0"
DEFAULT_SYSTEM_PROMPT = os.environ.get("LOCAL_SYSTEM_PROMPT", "").strip()
OFFLOAD_DIR = Path(os.environ.get("LOCAL_OFFLOAD_DIR", str(MODEL_PATH.parent / "offload" / MODEL_NAME)))
TRACE_JSONL = os.environ.get("LOCAL_TRACE_JSONL", "").strip()

state: dict[str, object] = {}
generation_lock = threading.Lock()
trace_lock = threading.Lock()


def text_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def append_trace(row: dict) -> None:
    if not TRACE_JSONL:
        return
    path = Path(TRACE_JSONL).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    with trace_lock, path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        stream.flush()


def load_model() -> None:
    if not MODEL_PATH.exists():
        raise FileNotFoundError(MODEL_PATH)
    using_npu = DEVICE.startswith("npu")
    if using_npu:
        import torch_npu  # noqa: F401 - registers torch.npu

        if not torch.npu.is_available():
            raise RuntimeError("LOCAL_DEVICE requests NPU, but torch.npu is unavailable")
    elif not torch.cuda.is_available():
        raise RuntimeError("CUDA PyTorch is required for the configured GPU/CPU offload deployment")
    OFFLOAD_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Loading {MODEL_NAME} from {MODEL_PATH}", flush=True)
    print(f"Device={DEVICE}, GPU budget={GPU_MEMORY}, CPU budget={CPU_MEMORY}", flush=True)
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if using_npu:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH,
            torch_dtype=torch.bfloat16,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
        ).to(DEVICE)
    else:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            max_memory={0: GPU_MEMORY, "cpu": CPU_MEMORY},
            offload_folder=OFFLOAD_DIR,
            offload_state_dict=True,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
        )
    model.eval()
    state["tokenizer"] = tokenizer
    state["model"] = model
    print(
        f"Device map: {getattr(model, 'hf_device_map', {'primary': str(model.device)})}",
        flush=True,
    )


def render_chat(tokenizer, messages: list[dict]) -> str:
    if DEFAULT_SYSTEM_PROMPT and (not messages or messages[0].get("role") != "system"):
        messages = [{"role": "system", "content": DEFAULT_SYSTEM_PROMPT}, *messages]
    kwargs = {"tokenize": False, "add_generation_prompt": True}
    chat_template = getattr(tokenizer, "chat_template", "") or ""
    if DISABLE_THINKING and "enable_thinking" in chat_template:
        kwargs["enable_thinking"] = False
    elif DISABLE_THINKING and messages:
        # openPangu switches the current turn through an explicit prompt tag.
        messages = [*messages[:-1], {**messages[-1], "content": messages[-1]["content"] + "\n/no_think"}]
    try:
        return tokenizer.apply_chat_template(messages, **kwargs)
    except TypeError:
        kwargs.pop("enable_thinking", None)
        if DISABLE_THINKING and messages:
            messages = [*messages[:-1], {**messages[-1], "content": messages[-1]["content"] + "\n/no_think"}]
        return tokenizer.apply_chat_template(messages, **kwargs)


def clean_answer(text: str) -> str:
    # openPangu wraps reasoning and final content in [unused16]/[unused17]
    # markers. Decode with special tokens intact so the final-answer boundary
    # remains observable, then strip the model-specific terminators here.
    if "[unused17]" in text:
        text = text.rsplit("[unused17]", 1)[-1]
    text = text.split("[unused10]", 1)[0]
    if DISABLE_THINKING:
        text = re.sub(r"<think>.*?</think>\s*", "", text, flags=re.DOTALL)
    text = (
        text.replace("<|im_end|>", "")
        .replace("<|endoftext|>", "")
        .replace("</s>", "")
    )
    return text.strip()


def generate(request: ChatRequest) -> tuple[str, int, int, int, float]:
    tokenizer = state["tokenizer"]
    model = state["model"]
    messages = [message.model_dump() for message in request.messages]
    prompt = render_chat(tokenizer, messages)
    encoded = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
    input_tokens = encoded["input_ids"].shape[-1]
    if input_tokens > MAX_INPUT_TOKENS:
        raise HTTPException(400, f"input has {input_tokens} tokens; limit is {MAX_INPUT_TOKENS}")
    target_device = model.get_input_embeddings().weight.device
    encoded = {key: value.to(target_device) for key, value in encoded.items()}
    sampling = request.temperature > 0
    deployment_limit = MAX_STRUCTURED_OUTPUT_TOKENS if request.response_format else MAX_OUTPUT_TOKENS
    effective_max_tokens = min(request.max_tokens, deployment_limit)
    started = time.perf_counter()
    with generation_lock, torch.inference_mode():
        output = model.generate(
            **encoded,
            max_new_tokens=effective_max_tokens,
            do_sample=sampling,
            temperature=request.temperature if sampling else None,
            pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
        )
        if DEVICE.startswith("npu"):
            torch.npu.synchronize()
    generated_ids = output[0, input_tokens:]
    answer = clean_answer(tokenizer.decode(generated_ids, skip_special_tokens=False))
    elapsed = time.perf_counter() - started
    return answer, input_tokens, int(generated_ids.numel()), effective_max_tokens, elapsed


def generate_batch(
    requests: list[ChatRequest],
) -> tuple[list[tuple[str, int, int]], int, float]:
    """Generate a deterministic batch with one shared output-token limit."""
    if not requests:
        return [], 0, 0.0
    max_tokens = {request.max_tokens for request in requests}
    temperatures = {request.temperature for request in requests}
    structured = {bool(request.response_format) for request in requests}
    if len(max_tokens) != 1 or len(temperatures) != 1 or len(structured) != 1:
        raise HTTPException(400, "batch requests must share max_tokens, temperature, and response_format mode")
    temperature = temperatures.pop()
    tokenizer = state["tokenizer"]
    model = state["model"]
    prompts = [
        render_chat(tokenizer, [message.model_dump() for message in request.messages])
        for request in requests
    ]
    previous_padding_side = tokenizer.padding_side
    tokenizer.padding_side = "left"
    try:
        encoded = tokenizer(prompts, return_tensors="pt", add_special_tokens=False, padding=True)
    finally:
        tokenizer.padding_side = previous_padding_side
    input_tokens = [int(value) for value in encoded["attention_mask"].sum(dim=1).tolist()]
    if max(input_tokens) > MAX_INPUT_TOKENS:
        raise HTTPException(400, f"batch input has {max(input_tokens)} tokens; limit is {MAX_INPUT_TOKENS}")
    padded_input_length = int(encoded["input_ids"].shape[-1])
    target_device = model.get_input_embeddings().weight.device
    encoded = {key: value.to(target_device) for key, value in encoded.items()}
    sampling = temperature > 0
    deployment_limit = MAX_STRUCTURED_OUTPUT_TOKENS if structured.pop() else MAX_OUTPUT_TOKENS
    effective_max_tokens = min(max_tokens.pop(), deployment_limit)
    started = time.perf_counter()
    with generation_lock, torch.inference_mode():
        output = model.generate(
            **encoded,
            max_new_tokens=effective_max_tokens,
            do_sample=sampling,
            temperature=temperature if sampling else None,
            pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
        )
        if DEVICE.startswith("npu"):
            torch.npu.synchronize()
    elapsed = time.perf_counter() - started
    rows: list[tuple[str, int, int]] = []
    for index in range(len(requests)):
        generated_ids = output[index, padded_input_length:]
        answer = clean_answer(tokenizer.decode(generated_ids, skip_special_tokens=False))
        rows.append((answer, input_tokens[index], int(generated_ids.numel())))
    return rows, effective_max_tokens, elapsed


@asynccontextmanager
async def lifespan(_: FastAPI):
    load_model()
    yield
    state.clear()


app = FastAPI(title="Local Transformers OpenAI adapter", lifespan=lifespan)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "model": MODEL_NAME,
        "device": DEVICE,
        "loaded": "model" in state,
        "max_input_tokens": MAX_INPUT_TOKENS,
        "max_output_tokens": MAX_OUTPUT_TOKENS,
        "max_structured_output_tokens": MAX_STRUCTURED_OUTPUT_TOKENS,
    }


@app.get("/v1/models")
def models() -> dict:
    return {"object": "list", "data": [{"id": MODEL_NAME, "object": "model", "owned_by": "local"}]}


@app.post("/v1/chat/completions")
def chat(request: ChatRequest) -> dict:
    request_id = f"chatcmpl-{uuid.uuid4().hex}"
    started = time.time()
    try:
        answer, prompt_tokens, completion_tokens, effective_max_tokens, elapsed = generate(request)
    except Exception as error:
        append_trace(
            {
                "id": request_id,
                "created": int(started),
                "model": MODEL_NAME,
                "status": "error",
                "messages_sha256": text_hash(
                    json.dumps([message.model_dump() for message in request.messages], ensure_ascii=False, sort_keys=True)
                ),
                "temperature": request.temperature,
                "max_tokens": request.max_tokens,
                "error_type": type(error).__name__,
                "error": str(error)[:1000],
            }
        )
        raise
    append_trace(
        {
            "id": request_id,
            "created": int(started),
            "model": MODEL_NAME,
            "status": "ok",
            "messages_sha256": text_hash(
                json.dumps([message.model_dump() for message in request.messages], ensure_ascii=False, sort_keys=True)
            ),
            "answer_sha256": text_hash(answer),
            "answer": answer,
            "temperature": request.temperature,
            "max_tokens": request.max_tokens,
            "effective_max_tokens": effective_max_tokens,
            "response_format": request.response_format,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "elapsed_seconds": elapsed,
        }
    )
    return {
        "id": request_id,
        "object": "chat.completion",
        "created": int(time.time()),
        "model": MODEL_NAME,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": answer},
            "finish_reason": "length" if completion_tokens >= effective_max_tokens else "stop",
        }],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
        "local_metrics": {"generation_seconds": elapsed},
    }


@app.post("/v1/chat/completions/batch")
def chat_batch(request: BatchChatRequest) -> dict:
    started = time.time()
    rows, effective_max_tokens, elapsed = generate_batch(request.requests)
    responses = []
    for index, ((answer, prompt_tokens, completion_tokens), source) in enumerate(
        zip(rows, request.requests, strict=True)
    ):
        responses.append(
            {
                "id": f"chatcmpl-{uuid.uuid4().hex}",
                "object": "chat.completion",
                "created": int(started),
                "model": MODEL_NAME,
                "choices": [{
                    "index": 0,
                    "message": {"role": "assistant", "content": answer},
                    "finish_reason": "length" if completion_tokens >= effective_max_tokens else "stop",
                }],
                "usage": {
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": prompt_tokens + completion_tokens,
                },
                "local_metrics": {
                    "batch_generation_seconds": elapsed,
                    "batch_size": len(rows),
                    "batch_index": index,
                    "requested_max_tokens": source.max_tokens,
                },
            }
        )
    return {"responses": responses, "local_metrics": {"generation_seconds": elapsed, "batch_size": len(rows)}}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=11435)
    args = parser.parse_args()
    uvicorn.run(app, host=args.host, port=args.port, workers=1)


if __name__ == "__main__":
    main()
