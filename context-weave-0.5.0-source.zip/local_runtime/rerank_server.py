"""CPU-only, loopback-only source-passage cross-encoder.

Loads safetensors from a local, hash-manifested model directory. Never runs
remote model code; never generates text. No request contents are logged.
"""
import argparse
import hashlib
import json
import threading
from pathlib import Path

import torch
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel, Field
from transformers import AutoModelForSequenceClassification, AutoTokenizer


class Request(BaseModel):
    query: str = Field(min_length=1, max_length=6000)
    documents: list[str] = Field(min_length=1, max_length=160)


def make_app(model_path, threads=6):
    torch.set_num_threads(threads)
    path = Path(model_path)
    files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.iterdir())
             if p.is_file() and p.suffix in {".json", ".txt", ".safetensors"}}
    identity = "ms-marco-MiniLM-L6-v2:" + hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, trust_remote_code=False)
    model = AutoModelForSequenceClassification.from_pretrained(path, local_files_only=True,
                                                              trust_remote_code=False, use_safetensors=True).to("cpu").eval()
    gate = threading.Lock()
    app = FastAPI()

    @app.get("/health")
    def health():
        return {"status": "ready", "device": "cpu", "model": "cross-encoder/ms-marco-MiniLM-L6-v2",
                "identity": identity, "max_length": 384, "threads": threads}

    @app.post("/rerank")
    def rerank(request: Request):
        scores = []
        with gate, torch.inference_mode():
            for offset in range(0, len(request.documents), 16):
                docs = request.documents[offset:offset+16]
                inputs = tokenizer([request.query]*len(docs), docs, padding=True,
                                   truncation=True, max_length=384, return_tensors="pt")
                scores.extend(model(**inputs).logits.flatten().tolist())
        return {"scores": scores, "identity": identity}

    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--port", type=int, default=18092)
    parser.add_argument("--threads", type=int, default=6)
    args = parser.parse_args()
    uvicorn.run(make_app(args.model, args.threads), host="127.0.0.1", port=args.port,
                access_log=False, log_level="warning")
