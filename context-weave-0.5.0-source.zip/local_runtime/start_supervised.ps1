param(
    [Parameter(Mandatory=$true)][string]$ModelPath,
    [Parameter(Mandatory=$true)][string]$PythonPath,
    [string]$RuntimeOverlay = '',
    [int]$Port = 18091,
    [double]$GenerationTimeout = 90,
    [double]$CancelGrace = 5,
    [double]$RequestTimeout = 150
)
$ErrorActionPreference = 'Stop'
$env:PYTHONPATH = $RuntimeOverlay
$env:HF_DEACTIVATE_ASYNC_LOAD = '1'
$env:HF_HUB_OFFLINE = '1'
$env:TRANSFORMERS_OFFLINE = '1'
$env:LOCAL_MODEL_PATH = (Resolve-Path -LiteralPath $ModelPath).Path
$env:LOCAL_MODEL_NAME = 'Qwen3.5-4B'
$env:LOCAL_DEVICE = 'cuda:0'
$env:LOCAL_GPU_MEMORY = '9GiB'
$env:LOCAL_CPU_MEMORY = '18GiB'
$env:LOCAL_MAX_INPUT_TOKENS = '8192'
$env:LOCAL_MAX_OUTPUT_TOKENS = '1024'
$env:LOCAL_MAX_STRUCTURED_OUTPUT_TOKENS = '1024'
$env:LOCAL_DISABLE_THINKING = '1'
$env:LOCAL_SYSTEM_PROMPT = ''
$env:LOCAL_TRACE_JSONL = ''
$env:LOCAL_GENERATION_TIMEOUT = [string]$GenerationTimeout
$env:LOCAL_CANCEL_GRACE = [string]$CancelGrace
$env:LOCAL_REQUEST_TIMEOUT = [string]$RequestTimeout
$env:LOCAL_STARTUP_TIMEOUT = '90'
$env:LOCAL_QUEUE_LIMIT = '16'
Remove-Item Env:\OPENROUTER_API_KEY, Env:\OPENAI_API_KEY, Env:\DASHSCOPE_API_KEY, Env:\MEMORY_API_KEY -ErrorAction SilentlyContinue
$serverPath = Join-Path $PSScriptRoot 'competition\supervised_server.py'
& $PythonPath -u $serverPath --host 127.0.0.1 --port $Port
exit $LASTEXITCODE
