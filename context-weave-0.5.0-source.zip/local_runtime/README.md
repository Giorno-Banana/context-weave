# Supervised Qwen runtime 0.4.1

Use `start_supervised.ps1`, not the historical `competition/runs/start-context-weave-qwen.ps1`. The historical adapter files remain as loading helpers and a reproduction reference. The new worker calls `inference_runtime.generate` for BOTH single and batch requests; it does not call the legacy unguarded `generate` function.

```powershell
.\local_runtime\start_supervised.ps1 -ModelPath C:\models\Qwen3.5-4B -PythonPath C:\model-venv\Scripts\python.exe -Port 18091
```

`-RuntimeOverlay` optionally selects the existing workstation's pinned Python package overlay. It is not required when the venv already contains the pinned dependencies. Deployed versions: Python 3.10, torch 2.11.0+cu128, Transformers 5.16.1, safetensors 0.8.0, accelerate 1.14.0. The weight/tokenizer hashes and server source hashes are in MODEL_MANIFEST.json. Recompute with `python local_runtime/freeze_runtime.py --model-dir PATH` after a source/configuration change; freeze the resulting identity before creating a new database.

The model uses BF16, 8192 input tokens, 1024 output tokens, greedy generation, no thinking, a 9 GiB GPU weight placement budget and an 18 GiB CPU placement budget. The placement budget is not a reservation for total GPU usage. Above 4096 input tokens, prefill runs in chunks of 1024. No quantization or model swap is introduced. JSON response_format is still prompt-based, not grammar constrained; Add validates span IDs and rejects malformed or truncated replies.

The launcher listens only on loopback. Health exposes ready/busy/recovering, queue depth, worker PID, sanitized error codes, counters and memory timings. Health is reachable during model load; callers must inspect `loaded`, not merely HTTP 200. Add/Search remains a separate authenticated API.

Deadlines: generation 90 s, cancellation grace 5 s, total HTTP request 150 s including queue time, model startup 90 s. The Add client timeout is 180 s. Configurable launcher parameters are GenerationTimeout, CancelGrace and RequestTimeout; changing them requires a new manifest/profile. At most 16 waiting requests and one active generation are allowed. Soft cancellation never returns partial success. If CUDA/prefill cannot respond to cancellation, the parent kills and reaps that worker before loading another. Startup/crash loops are bounded to three starts per five minutes. The worker exits if its parent dies on Windows.

The supervisor can recover a failed process, but cannot make a slow GPU faster, eliminate all driver failures, or guarantee a multi-day Full. A crash loses only the active model response; the memory service's existing idempotent batch checkpoints handle the subsequent retry. Logs do not include source text, generated answers or raw provider exception messages.

Synthetic sustained test (does not use Bailian or create an official task):

```powershell
python local_runtime/stress_runtime.py --seconds 14400 --output runs/runtime-soak.json
```

The test mixes identical Add anchors, variable-length Add prompts, batched requests and 5k–6k-token prefill. It records only counts, timings, memory and response hashes. Acceptance requires no failures or restarts, a bounded post-request memory plateau, identical anchor outputs and an end/start anchor median ratio at most 1.5. This is a runtime test, not a retrieval-quality benchmark.
