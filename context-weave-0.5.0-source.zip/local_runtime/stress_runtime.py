"""Synthetic sustained load with identical anchor prompts and safe metrics only."""
import argparse
import hashlib
import json
import statistics
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from adaptive_evidence.add_indexer import LocalAddIndexer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default='http://127.0.0.1:18091')
    parser.add_argument('--seconds', type=float, default=14400)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    trace = args.output.with_suffix('.jsonl')
    client = httpx.Client(base_url=args.url, timeout=160, trust_env=False)
    indexer = LocalAddIndexer('Qwen3.5-4B', 'synthetic-runtime-test', max_attempts=1)
    sentence = ('Maya Chen booked a train to Oslo for November 18. The meeting is in the library. '
                '原文记录：蓝色展品将在周五送达，联系人是李明，运输采用铁路。 ')
    anchor = [(f'Project {i}: ' + sentence * 8)[:940] for i in range(2)]
    started = time.monotonic()
    initial = client.get('/health').json()
    assert initial['loaded'], 'Model must be ready before load testing'
    anchors, rows, failures = [], [], []
    report = dict(synthetic_only=True, official_evaluation=False, started=datetime.now(timezone.utc).isoformat(),
                  requested_seconds=args.seconds, initial_health=initial, status='running')

    def save(final=False):
        metrics = [r['metrics'] for r in rows if 'metrics' in r]
        report.update(elapsed_seconds=round(time.monotonic()-started, 2), requests=len(rows),
                      failures=failures, anchors=len(anchors), final_health=client.get('/health').json())
        if metrics:
            for field in ('allocated_mib', 'reserved_mib'):
                report[field] = dict(min=min(m[field] for m in metrics), max=max(m[field] for m in metrics))
            report['max_peak_reserved_mib'] = max(m['peak_reserved_mib'] for m in metrics)
        if len(anchors) >= 20:
            first = statistics.median(r['metrics']['generation_seconds'] for r in anchors[2:12])
            last = statistics.median(r['metrics']['generation_seconds'] for r in anchors[-10:])
            report['anchor_comparison'] = dict(first_median_seconds=first, last_median_seconds=last,
                last_over_first=round(last/first, 4), identical_outputs=len({r['answer_sha256'] for r in anchors}) == 1)
        if final:
            baseline = report.get('anchor_comparison', {})
            memory_ok = all(report[k]['max']-report[k]['min'] <= 128 for k in ('allocated_mib', 'reserved_mib'))
            stable = baseline.get('last_over_first', 999) <= 1.5 and baseline.get('identical_outputs', False)
            same_worker = report['final_health']['counters']['starts'] == initial['counters']['starts']
            report['acceptance'] = dict(no_failures=not failures, memory_plateau=memory_ok,
                                        anchor_stable=stable, no_restarts=same_worker)
            report['status'] = 'passed' if all(report['acceptance'].values()) else 'failed'
        args.output.write_text(json.dumps(report, indent=2), encoding='utf-8')

    try:
        with trace.open('x', encoding='utf-8') as stream:
            index = 0
            while time.monotonic()-started < args.seconds:
                mode = index % 4
                texts = anchor if mode == 0 else [(sentence * 10)[:150 + (index * 137 % 790)] for _ in range(2)]
                payload = indexer._payload(texts)
                endpoint = '/v1/chat/completions'
                kind = 'anchor' if mode == 0 else 'variable_add'
                if mode == 2:
                    kind, endpoint = 'batch', endpoint + '/batch'
                    payload = {'requests': [payload, payload]}
                elif mode == 3:
                    # About 6k input tokens: exercises chunked prefill, with a
                    # tiny answer so output length cannot hide prefill slowdown.
                    kind = 'long_prefill'
                    payload = dict(model='Qwen3.5-4B', temperature=0, max_tokens=32,
                        messages=[dict(role='system', content='Read the data and reply with the single word ready.'),
                                  dict(role='user', content=sentence * (140 + index % 20))])
                began = time.monotonic()
                response = client.post(endpoint, json=payload)
                row = dict(index=index, kind=kind, http_status=response.status_code,
                           wall_seconds=round(time.monotonic()-began, 6))
                if response.status_code == 200:
                    body = response.json()
                    replies = body['responses'] if mode == 2 else [body]
                    row['metrics'] = body['local_metrics']
                    row['answer_sha256'] = hashlib.sha256(json.dumps(
                        [r['choices'][0]['message']['content'] for r in replies], ensure_ascii=False).encode()).hexdigest()
                    try:
                        if mode != 3:
                            for reply in replies:
                                indexer._validate(reply, texts)
                        else:
                            assert replies[0]['choices'][0]['finish_reason'] == 'stop'
                        row['valid'] = True
                    except (ValueError, AssertionError, KeyError, TypeError):
                        row['valid'] = False
                        failures.append(dict(index=index, reason='response_validation'))
                    if mode == 0:
                        anchors.append(row)
                else:
                    failures.append(dict(index=index, reason='http', status=response.status_code))
                rows.append(row)
                stream.write(json.dumps(row) + '\n')
                stream.flush()
                if index % 20 == 0:
                    save()
                if len(failures) >= 3:
                    break
                index += 1
        save(final=True)
        print(json.dumps(report, indent=2))
    finally:
        indexer.close()
        client.close()


if __name__ == '__main__':
    main()
