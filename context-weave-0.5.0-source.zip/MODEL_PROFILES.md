# Model profiles

0.4.1 local profile: Qwen3.5-4B via the supervised loopback server on port 18091. Use local_runtime/profile.txt. Runtime revision: `sha256-82566a6da25518d98b91c78ce9a7c5a3d09aee59dd25db5b123f65811ed8acfe`. Batch size 2, one in-flight model request, Search planner disabled, separate data/v041-local/memory.sqlite3 database. The HTTP response always names Qwen3.5-4B. The runtime and tokenizer/weight manifest is under local_runtime/; weights and dependency binaries are external.

The explicit OpenRouter profile uses OpenAI GPT-4o-mini and env.openrouter.example. It retains the established cloud prompt and output validation. Use a different database and supply the private OpenRouter credential. Local failures do not fall back to this profile.

The local generation runtime changed; source-span selection instructions, 1,000-character chunking, text-embedding-v4 and Search behavior did not. The local JSON schema remains in the prompt and outputs are validated. API/database profile identity includes model, revision and batch size. Freeze source and configuration before an official task. A revision change must not reuse an old profile's database or batch checkpoints.

0.4.0 officially completed Smoke with 59.47 over 46 items. 0.4.1 has only local validation at present. Organizer eligibility and actual model disclosure are separate from whether the code can serve a profile.
