"""Budgeted source evidence selection, without generated facts or answers.

Method references are documented in PROVENANCE.md. All state is held by a
single user's immutable index; lexical views never cross scope boundaries.
"""
from __future__ import annotations

import math
import re
from collections import defaultdict

import numpy as np

from .core import content_tokens
from .retrieval_views import RetrievalViews


OVERVIEW = re.compile(r"\b(summari[sz]e|summary|overview|timeline|main themes|major milestones|over time)\b|总结|概览|时间线", re.I)


def overview_order(index, ranked, query):
    """Reserve breadth for overview questions; never infer a time from IDs."""
    if not OVERVIEW.search(query):
        return ranked
    selected = list(ranked[:6])
    seen = set(selected)
    per_session = defaultdict(int)
    for i in selected:
        per_session[index.rows[i]["session_id"]] += 1
    for cap in (1, 2, 4):
        for i in ranked[:200]:
            key = index.rows[i]["session_id"]
            if i not in seen and per_session[key] < cap:
                selected.append(i)
                seen.add(i)
                per_session[key] += 1
    return selected + [i for i in ranked if i not in seen]


def rank_evidence(index, queries, vectors, dense_scores, base_scores, limit):
    """Fuse raw, stemmed and neighboring views, then diversify lightly."""
    with index.view_lock:
        if index.views is None:
            index.views = RetrievalViews(index)
        views = index.views
    scores = base_scores.copy()
    for n, query in enumerate(queries):
        weight = 1.0 if n == 0 else .2 / (len(queries) - 1)
        streams = [(views.lexical(query, "turns", limit), .65),
                   (views.lexical(query, "windows", limit), .25),
                   (np.argsort(-(views.pooled @ vectors[n]), kind="stable")[:limit], .25)]
        for order, channel in streams:
            for rank, i in enumerate(order, 1):
                scores[i] += weight * channel / (60 + rank)
    order = list(map(int, np.lexsort((-dense_scores, -scores))))
    pool = order[:limit]
    if not pool:
        return order
    relevance = scores[pool] / max(float(scores[pool].max()), 1e-12)
    # Penalize repeats of the same semantic content gently. Never erase a
    # dated event or suppress a correction merely for sharing topic words.
    similarity = np.clip(index.matrix[pool] @ index.matrix[pool].T, 0, 1)
    redundancy = np.zeros(len(pool))
    available = np.ones(len(pool), dtype=bool)
    query_terms = content_tokens(queries[0])
    covered = set()
    selected = []
    for _ in pool:
        coverage = np.asarray([len((index.terms[i] & query_terms) - covered)
                               / max(len(query_terms), 1) for i in pool])
        utility = .92 * relevance - .06 * redundancy + .02 * coverage
        utility[~available] = -np.inf
        winner = int(np.argmax(utility))
        selected.append(pool[winner])
        covered.update(index.terms[pool[winner]] & query_terms)
        available[winner] = False
        redundancy = np.maximum(redundancy, similarity[winner])
    return selected + order[limit:]


def pack_evidence(store, index, ranked, top_k):
    """Reserve actual characters and slots for context before filling the tail.

    Direct hits keep relevance order. Context comes from the same ordered Add
    request only. Opaque session/request IDs cannot establish chronology.
    """
    budget = store.config.context_chars
    selected, seen = [], set()
    spans = defaultdict(list)
    used = 0

    def take(i, char_limit=budget, slot_limit=top_k):
        nonlocal used
        if i in seen or len(selected) >= slot_limit:
            return False
        row = index.rows[i]
        if any(a <= row["start"] and b >= row["end"] for a, b in spans[row["source_id"]]):
            return False
        text = store.render(row)
        if used + len(text) > char_limit:
            return False
        selected.append(i)
        seen.add(i)
        spans[row["source_id"]].append((row["start"], row["end"]))
        used += len(text)
        return True

    if top_k == 1:
        for i in ranked:
            if take(i):
                break
        return selected
    # Always allow the best whole source when it fits the total budget, even
    # when it is larger than the initial direct-hit allocation.
    for i in ranked:
        if take(i):
            break
    direct_chars = max(used, int(budget * .65))
    direct_slots = max(1, math.ceil(top_k * .65))
    for i in ranked:
        take(i, direct_chars, direct_slots)
    seeds = list(selected)
    # Round-robin by distance prevents the first long episode monopolizing
    # the context allocation. A reserve is returned to direct hits if unused.
    context_limit = max(used, int(budget * .9))
    context_slots = max(len(selected), math.ceil(top_k * .9))
    neighbors = [sorted((j for j in index.neighbors[i] if j != i),
                        key=lambda j: (abs(index.rows[j]["position"] - index.rows[i]["position"]), j))
                 for i in seeds]
    for distance in range(max(map(len, neighbors), default=0)):
        for group in neighbors:
            if distance < len(group):
                take(group[distance], context_limit, context_slots)
    for i in ranked:
        take(i)
    return selected
