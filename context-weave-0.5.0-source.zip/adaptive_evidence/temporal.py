"""Conservative calendar metadata derived only from a source's own time.

Original wording is never replaced. These are calendar interpretations of
relative phrases, not a claim that the described event actually occurred.
"""
import re
from datetime import datetime, timedelta, timezone


RELATIVE = re.compile(r"\b(yesterday|tomorrow|today|last night|(?:last|this|next) (?:week|month|year)|\d{1,3} days? ago)\b", re.I)
LEADING_DATE = re.compile(r"^\s*\[(\d{4}-\d{2}-\d{2})(?:[ T][^\]]*)?\]")
PREFIX = re.compile(r"^\s*\[([^\]]{1,160})\]")
NAMED_DATE = re.compile(r"\b(\d{1,2}) (January|February|March|April|May|June|July|August|September|October|November|December),? (\d{4})\b", re.I)


def calendar_note(content, timestamp):
    if not RELATIVE.search(content):
        return ""
    try:
        if timestamp is not None:
            anchor = datetime.fromtimestamp(timestamp / 1000, timezone.utc).date()
            basis = "message timestamp, UTC"
        else:
            match = LEADING_DATE.match(content)
            if match:
                anchor = datetime.strptime(match[1], "%Y-%m-%d").date()
            else:
                prefix = PREFIX.match(content)
                named = NAMED_DATE.search(prefix[1]) if prefix else None
                if named is None:
                    return ""
                anchor = datetime.strptime(" ".join(named.groups()), "%d %B %Y").date()
            basis = "source date prefix"
        notes = []
        for phrase in dict.fromkeys(m.group().lower() for m in RELATIVE.finditer(content)):
            if phrase in {"yesterday", "last night", "today", "tomorrow"}:
                delta = {"yesterday": -1, "last night": -1, "today": 0, "tomorrow": 1}[phrase]
                value = (anchor + timedelta(days=delta)).isoformat()
            elif phrase.endswith("ago"):
                value = (anchor - timedelta(days=int(phrase.split()[0]))).isoformat()
            else:
                direction, unit = phrase.split()
                shift = {"last": -1, "this": 0, "next": 1}[direction]
                if unit == "week":
                    start = anchor - timedelta(days=anchor.weekday()) + timedelta(weeks=shift)
                    value = f"{start.isoformat()}..{(start+timedelta(days=6)).isoformat()} (calendar week)"
                elif unit == "month":
                    month_index = anchor.year*12 + anchor.month-1 + shift
                    year, month = divmod(month_index, 12)
                    value = f"{year:04d}-{month+1:02d} (month only)"
                else:
                    value = f"{anchor.year+shift} (year only)"
            notes.append(f"{phrase!r}: {value}")
            if len(notes) == 4:
                break
        return f"\n[Calendar metadata; anchor={anchor.isoformat()} from {basis}; " + "; ".join(notes) + "]"
    except (ValueError, OverflowError, OSError):
        return ""
