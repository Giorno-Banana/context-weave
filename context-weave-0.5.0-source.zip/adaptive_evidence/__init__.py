"""Evidence-only memory service; no dataset or answer-generation dependency."""

__version__ = "0.5.0"
