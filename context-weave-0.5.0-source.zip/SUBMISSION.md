# Submission profile — 0.5.0

## Deployment profile

- Add: local Qwen3.5-4B, BF16, thinking disabled, greedy decoding, two chunks per request. The supervised 0.4.1 model runtime is unchanged; its weights and runtime hashes are in `local_runtime/MODEL_MANIFEST.json`.
- Embeddings: Bailian text-embedding-v4, 1024 dimensions.
- Search: bounded dense, BM25, Porter and neighboring-context rank fusion; mild diversity; local CPU cross-encoder reranking; reserved character/slot budgets for source neighbors.
- Reranker: cross-encoder/ms-marco-MiniLM-L6-v2, CPU, 384-token input, 96 candidates. It scores passages and generates no text. The manifest identifies the exact downloaded model files.
- Original source text is retained. Calendar annotations are separately marked metadata anchored only to source timestamps or explicit source date prefixes. Calendar months/years retain their granularity. Overview queries include representatives from different sessions.
- Evidence is scoped to the supplied user. Search does not generate a final answer, use test labels, or reuse evidence across users.
- Candidate endpoints: `https://wzm.tail36b9f2.ts.net/v050/add` and `/v050/search`; credentials are supplied privately. Add/Search concurrency 16/16, top_k 100, returned text budget 24,000 characters including metadata.

